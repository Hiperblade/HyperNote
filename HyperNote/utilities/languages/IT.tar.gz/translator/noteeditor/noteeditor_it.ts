<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS []>
<TS version="2.0">
<context>
    <name>ENoteBook::MoveToDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>top of selected note</source>
<translation type="unfinished" variants="no">sopra la nota selezionata</translation>
    </message>
    <message>
        <source>Add to...</source>
<translation type="unfinished" variants="no">Aggiungi a...</translation>
    </message>
    <message>
        <source>bottom of selected note</source>
<translation type="unfinished" variants="no">sotto la nota selezionata</translation>
    </message>
</context>
<context>
    <name>ENoteBook::MoveToDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Enter password:</source>
<translation type="unfinished" variants="no">Inserire la password:</translation>
    </message>
    <message>
        <source>Invalid password</source>
<translation type="unfinished" variants="no">Password non valida</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>You have not assigned a security password. Please go to [Settings] - [Security] and create a password, and use the password to proceed.</source>
<translation type="unfinished" variants="no">Non è stata ancora assegnata una password di protezione.Andare a [Impostazioni] - [Protezione] e creare una password, quindi utilizzare la password per procedere.</translation>
    </message>
</context>
<context>
    <name>ENoteBook::TemplateDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>EnoteMessageBox</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ReNameDialog</name>
    <message>
        <source>Ok</source>
<translation type="unfinished" variants="no">Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>The name already exist. </source>
<translation type="unfinished" variants="no">Il nome esiste già.</translation>
    </message>
    <message>
        <source>please input the name:</source>
<translation type="unfinished" variants="no">Inserire il nome:</translation>
    </message>
</context>
<context>
    <name>ENoteTagWidget::TagWidget</name>
    <message>
        <source>Add</source>
<translation type="unfinished" variants="no">Aggiungi</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Tag already exists</source>
<translation type="unfinished" variants="no">Il tag esiste già</translation>
    </message>
    <message>
        <source>Input Tag</source>
<translation type="unfinished" variants="no">Inserisci</translation>
    </message>
    <message>
        <source>Delete the tag:%1?</source>
<translation type="unfinished" variants="no">Eliminare il tag:%1?</translation>
    </message>
    <message>
        <source>Edit Tag</source>
<translation type="unfinished" variants="no">Modifica tag</translation>
    </message>
</context>
<context>
    <name>ENoteBook::ToolWidget</name>
    <message>
        <source>Big</source>
<translation type="unfinished" variants="no">Grande</translation>
    </message>
    <message>
        <source>Gray</source>
<translation type="unfinished" variants="no">Normale</translation>
    </message>
    <message>
        <source>Page</source>
<translation type="unfinished" variants="no">Pagina</translation>
    </message>
    <message>
        <source>Black</source>
<translation type="unfinished" variants="no">Scuro</translation>
    </message>
    <message>
        <source>Color</source>
<translation type="unfinished" variants="no">Colore</translation>
    </message>
    <message>
        <source>Light</source>
<translation type="unfinished" variants="no">Chiaro</translation>
    </message>
    <message>
        <source>Small</source>
<translation type="unfinished" variants="no">Sottile</translation>
    </message>
    <message>
        <source>Highlighter</source>
<translation type="unfinished" variants="no">Evidenziatore</translation>
    </message>
    <message>
        <source>Camera</source>
<translation type="unfinished" variants="no">Fotocamera</translation>
    </message>
    <message>
        <source>Eraser</source>
<translation type="unfinished" variants="no">Gomma</translation>
    </message>
    <message>
        <source>Marker</source>
<translation type="unfinished" variants="no">Pennarello</translation>
    </message>
    <message>
        <source>Medium</source>
<translation type="unfinished" variants="no">Media</translation>
    </message>
    <message>
        <source>Pencil</source>
<translation type="unfinished" variants="no">Matita</translation>
    </message>
    <message>
        <source>Photos</source>
<translation type="unfinished" variants="no">Foto</translation>
    </message>
    <message>
        <source>Fountain</source>
<translation type="unfinished" variants="no">Penna stilo</translation>
    </message>
    <message>
        <source>Pen stroke</source>
<translation type="unfinished" variants="no">Tratto penna</translation>
    </message>
    <message>
        <source>Insert from</source>
<translation type="unfinished" variants="no">Inserisci da</translation>
    </message>
    <message>
        <source>Thumbnail</source>
<translation type="unfinished" variants="no">Miniatura</translation>
    </message>
    <message>
        <source>Navigate to</source>
<translation type="unfinished" variants="no">Vai a</translation>
    </message>
    <message>
        <source>Ball point</source>
<translation type="unfinished" variants="no">Penna a sfera</translation>
    </message>
</context>
<context>
    <name>ENoteBook::NoteList</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>Sort</source>
<translation type="unfinished" variants="no">Ordina</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Enter</source>
<translation type="unfinished" variants="no">Entra</translation>
    </message>
    <message>
        <source>N - O</source>
<translation type="unfinished" variants="no">Nuovi-Prec.</translation>
    </message>
    <message>
        <source>O - N</source>
<translation type="unfinished" variants="no">Prec.-Nuovi</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Edit Note</source>
<translation type="unfinished" variants="no">Modifica Nota</translation>
    </message>
    <message>
        <source>Enter password:</source>
<translation type="unfinished" variants="no">Inserire la password:</translation>
    </message>
    <message>
        <source>Invalid password</source>
<translation type="unfinished" variants="no">Password non valida</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>Search</source>
<translation type="unfinished" variants="no">Cerca</translation>
    </message>
    <message>
        <source>Untitled Note</source>
<translation type="unfinished" variants="no">Senza titolo</translation>
    </message>
    <message>
        <source>by Date</source>
<translation type="unfinished" variants="no">per data</translation>
    </message>
    <message>
        <source>by Name</source>
<translation type="unfinished" variants="no">per nome</translation>
    </message>
    <message>
        <source>By date</source>
<translation type="unfinished" variants="no">per data</translation>
    </message>
    <message>
        <source>NoteBooks</source>
<translation type="unfinished" variants="no">Note</translation>
    </message>
    <message>
        <source>You have not assigned a security password. Please go to [Settings] - [Security] and create a password, and use the password to proceed.</source>
<translation type="unfinished" variants="no">Non è stata ancora assegnata una password di protezione.Andare a [Impostazioni] - [Protezione] e creare una password, quindi utilizzare la password per procedere.</translation>
    </message>
    <message>
        <source>Not enough space on device storage. Please delete some files, clean up Recycle Bin, and try again.</source>
<translation type="unfinished" variants="no">Spazio libero insufficiente. Eliminare alcuni file, svuotare il cestino e riprovare.</translation>
    </message>
    <message>
        <source>Adding to Evernote...</source>
<translation type="unfinished" variants="no">Caricamento su Evernote in corso...</translation>
    </message>
</context>
<context>
    <name>ENoteBook::PageWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>Save</source>
<translation type="unfinished" variants="no">Salva</translation>
    </message>
    <message>
        <source>Edit Note</source>
<translation type="unfinished" variants="no">Modifica Nota</translation>
    </message>
    <message>
        <source>Illegal name. Cannot be white space.</source>
<translation type="unfinished" variants="no">Il nome non può contenere solo spazi.</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>Illegal name. Cannot be blank.</source>
<translation type="unfinished" variants="no">Il campo del nome non può restare vuoto. Inserire un nome.</translation>
    </message>
    <message>
        <source>Note exported as /note/%1 in your SD card.</source>
<translation type="unfinished" variants="no">Nota esportate come /note/%1 nella scheda SD.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this page ?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare questa pagina?</translation>
    </message>
    <message>
        <source>You have no photo.</source>
<translation type="unfinished" variants="no">Nessuna foto da inserire.</translation>
    </message>
    <message>
        <source>Saving pages...</source>
<translation type="unfinished" variants="no">Salvataggio delle pagine...</translation>
    </message>
    <message>
        <source>Cannot find selected photo.  Please go to [Settings] - [Rescan for Media] and press [Execute] button to rescan for media files.</source>
<translation type="unfinished" variants="no">Impossibile trovare la foto selezionata. Andare a [Impostazioni] - [Ricerca file multimediali] e selezionare [Cerca] per avviare una nuova ricerca dei file multimediali.</translation>
    </message>
    <message>
        <source>Not enough space on SD card. Please delete some files and try again.</source>
<translation type="unfinished" variants="no">Spazio insufficiente nella scheda SD. Eliminare alcuni file e riprovare.</translation>
    </message>
    <message>
        <source>Not enough space on device storage. Please delete some files, clean up Recycle Bin, and try again.</source>
<translation type="unfinished" variants="no">Spazio libero insufficiente. Eliminare alcuni file, svuotare il cestino e riprovare.</translation>
    </message>
    <message>
        <source>The camera photo does not exist.</source>
<translation type="unfinished" variants="no">La foto non esiste.</translation>
    </message>
    <message>
        <source>Exporting page...</source>
<translation type="unfinished" variants="no">Esportazione pagina in corso...</translation>
    </message>
</context>
<context>
    <name>commonDlg::TagListWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Close search results</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>%1 items total</source>
<translation type="unfinished" variants="no">Totale di %1 elementi</translation>
    </message>
</context>
<context>
    <name>ENoteBook::NotePopMenuItem</name>
    <message>
        <source>Lock</source>
<translation type="unfinished" variants="no">Blocca</translation>
    </message>
    <message>
        <source>Delete</source>
<translation type="unfinished" variants="no">Elimina</translation>
    </message>
    <message>
        <source>Rename</source>
<translation type="unfinished" variants="no">Rinomina</translation>
    </message>
    <message>
        <source>Unlock</source>
<translation type="unfinished" variants="no">Sblocca</translation>
    </message>
    <message>
        <source>Add to Evernote</source>
<translation type="unfinished" variants="no">Aggiungi a Evernote</translation>
    </message>
    <message>
        <source>Merge...</source>
<translation type="unfinished" variants="no">Combina...</translation>
    </message>
</context>
<context>
    <name>ENoteBook::TemplateViewItem</name>
    <message>
        <source>Designed by </source>
<translation type="unfinished" variants="no">Realizzato da </translation>
    </message>
    <message>
        <source>Daily calories</source>
<translation type="unfinished" variants="no">Diario della dieta giornaliera</translation>
    </message>
    <message>
        <source>Blank</source>
<translation type="unfinished" variants="no">Bianco</translation>
    </message>
    <message>
        <source>Todai Vertical Wide</source>
<translation type="unfinished" variants="no">Protocollo Todai verticale esp.</translation>
    </message>
    <message>
        <source>Todai Wide Ruled</source>
<translation type="unfinished" variants="no">Protocollo Todai espanso</translation>
    </message>
    <message>
        <source>Calendar month with note</source>
<translation type="unfinished" variants="no">Calendario mensile con note</translation>
    </message>
    <message>
        <source>Graph (multi-weight)</source>
<translation type="unfinished" variants="no">Carta millim.(multi-weight)</translation>
    </message>
    <message>
        <source>Month in a page</source>
<translation type="unfinished" variants="no">Calendario mensile</translation>
    </message>
    <message>
        <source>Cover page I</source>
<translation type="unfinished" variants="no">Copertina I</translation>
    </message>
    <message>
        <source>Cornell Notes</source>
<translation type="unfinished" variants="no">Blocco note Cornell</translation>
    </message>
    <message>
        <source>Todai College Ruled</source>
<translation type="unfinished" variants="no">Protocollo Todai normale</translation>
    </message>
    <message>
        <source>Caligraphy paper</source>
<translation type="unfinished" variants="no">Fogli stile libero</translation>
    </message>
    <message>
        <source>Table of Contents I</source>
<translation type="unfinished" variants="no">Tabella I</translation>
    </message>
    <message>
        <source>Table of Contents II</source>
<translation type="unfinished" variants="no">Tabella II</translation>
    </message>
    <message>
        <source>2011 Yearly</source>
<translation type="unfinished" variants="no">Calendario 2011</translation>
    </message>
    <message>
        <source>2012 Yearly</source>
<translation type="unfinished" variants="no">Calendario 2012</translation>
    </message>
    <message>
        <source>Contacts</source>
<translation type="unfinished" variants="no">Contatti</translation>
    </message>
    <message>
        <source>Dot grid</source>
<translation type="unfinished" variants="no">Foglio puntinato</translation>
    </message>
    <message>
        <source>Axonometric</source>
<translation type="unfinished" variants="no">Assonometrica</translation>
    </message>
    <message>
        <source>Day agenda</source>
<translation type="unfinished" variants="no">Agenda giornaliera</translation>
    </message>
    <message>
        <source>Wide Ruled</source>
<translation type="unfinished" variants="no">Protocollo espanso</translation>
    </message>
    <message>
        <source>Pie chart</source>
<translation type="unfinished" variants="no">Grafico a torta</translation>
    </message>
    <message>
        <source>Vertical (Extra Wide)</source>
<translation type="unfinished" variants="no">Protocollo verticale extra</translation>
    </message>
    <message>
        <source>Electricity tracker</source>
<translation type="unfinished" variants="no">Electricity Record</translation>
    </message>
    <message>
        <source>Todai Vertical</source>
<translation type="unfinished" variants="no">Protocollo Todai verticale</translation>
    </message>
    <message>
        <source>Quad graph with note</source>
<translation type="unfinished" variants="no">Assonom. millim. con note</translation>
    </message>
    <message>
        <source>Graph paper</source>
<translation type="unfinished" variants="no">Carta millimetrata</translation>
    </message>
    <message>
        <source>To-do list</source>
<translation type="unfinished" variants="no">Agenda</translation>
    </message>
    <message>
        <source>Vertical (Wide)</source>
<translation type="unfinished" variants="no">Protocollo verticale espanso</translation>
    </message>
    <message>
        <source>Weekly agenda</source>
<translation type="unfinished" variants="no">Agenda settimanale</translation>
    </message>
    <message>
        <source>Verticle Ruled</source>
<translation type="unfinished" variants="no">Protocollo verticale</translation>
    </message>
    <message>
        <source>Cover page II</source>
<translation type="unfinished" variants="no">Copertina II</translation>
    </message>
    <message>
        <source>Quad graph paper</source>
<translation type="unfinished" variants="no">Assonometrica millimetrata</translation>
    </message>
    <message>
        <source>Blank (bordered)</source>
<translation type="unfinished" variants="no">Bianco con bordi</translation>
    </message>
    <message>
        <source>College Ruled</source>
<translation type="unfinished" variants="no">Protocollo normale</translation>
    </message>
    <message>
        <source>Vertical Blocks</source>
<translation type="unfinished" variants="no">Quadretti verticali</translation>
    </message>
    <message>
        <source>Block paper</source>
<translation type="unfinished" variants="no">Foglio a quadretti</translation>
    </message>
    <message>
        <source>Expense tracker</source>
<translation type="unfinished" variants="no">Libro mastro</translation>
    </message>
    <message>
        <source>Week in a page</source>
<translation type="unfinished" variants="no">Calendario settimanale</translation>
    </message>
    <message>
        <source>Four squares</source>
<translation type="unfinished" variants="no">Quattro quadrati</translation>
    </message>
    <message>
        <source>Log-log (two decades)</source>
<translation type="unfinished" variants="no">Diagramma a due assi</translation>
    </message>
    <message>
        <source>Contact card</source>
<translation type="unfinished" variants="no">Biglietto da visita</translation>
    </message>
    <message>
        <source>Double Spaced</source>
<translation type="unfinished" variants="no">Doppia spaziatura</translation>
    </message>
</context>
<context>
    <name>ImageLocateDialog</name>
    <message>
        <source>Apply</source>
<translation type="unfinished" variants="no">Applica</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Drag the picture to the location you want, and hit [Apply] to paste on the note.</source>
<translation type="unfinished" variants="no">Trascina la foto nella posizione desiderata e seleziona [Applica]
per incollarla sulla nota.</translation>
    </message>
</context>
<context>
    <name>ENoteBook::PageView</name>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
</context>
<context>
    <name>ENoteBook::NameDialog</name>
    <message>
        <source>Name:</source>
<translation type="unfinished" variants="no">Nome:</translation>
    </message>
</context>
<context>
    <name>ImageEditorWidget</name>
    <message>
        <source>Paste</source>
<translation type="unfinished" variants="no">Incolla</translation>
    </message>
    <message>
        <source>Reset</source>
<translation type="unfinished" variants="no">Reset</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ENoteBook::NoteViewItem</name>
    <message>
        <source>Tags:</source>
<translation type="unfinished" variants="no">Tag:</translation>
    </message>
    <message>
        <source>%1 pages total</source>
<translation type="unfinished" variants="no">%1 pagine</translation>
    </message>
</context>
<context>
    <name>ENoteBook::NoteListView</name>
    <message>
        <source>Enter password:</source>
<translation type="unfinished" variants="no">Inserire la password:</translation>
    </message>
    <message>
        <source>Invalid password</source>
<translation type="unfinished" variants="no">Password non valida</translation>
    </message>
    <message>
        <source>No search results</source>
<translation type="unfinished" variants="no">La ricerca non ha prodotto alcun risultato.</translation>
    </message>
    <message>
        <source>Security has not been set. Please go to [Settings] - [Security] and set up the password.</source>
<translation type="unfinished" variants="no">Non è ancora stata impostata la protezione. Andare a [Impostazioni] - [Protezione] e impostare la password.</translation>
    </message>
    <message>
        <source>Input name:</source>
<translation type="unfinished" variants="no">Inserire il nome:</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this note?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare questa nota?</translation>
    </message>
    <message>
        <source>You have not assigned a security password. Please go to [Settings] - [Security] and create a password, and use the password to proceed.</source>
<translation type="unfinished" variants="no">Non è stata ancora assegnata una password di protezione.Andare a [Impostazioni] - [Protezione] e creare una password, quindi utilizzare la password per procedere.</translation>
    </message>
</context>
<context>
    <name>EverNoteThread</name>
    <message>
        <source>Evernote haven&apos;t enough space</source>
<translation type="unfinished" variants="no">Spazio insufficiente nell&apos;account Evernote.</translation>
    </message>
    <message>
        <source>Cannot log in your Evernote account. Please go to [Settings] - [Accounts] and check your Evernote accounts.</source>
<translation type="unfinished" variants="no">Impossibile accedere all&apos;account Evernote.Andare a [Impostazioni] - [Servizio Cloud] e controllare l&apos;account Evernote.</translation>
    </message>
    <message>
        <source>Unknown error,please check your evernote account.</source>
<translation type="unfinished" variants="no">Errore sconosciuto.Controllare l&apos;account Evernote.</translation>
    </message>
    <message>
        <source>max page limited</source>
<translation type="unfinished" variants="no">Limite max. nota:</translation>
    </message>
    <message>
        <source>Successfully add to Evernote</source>
<translation type="unfinished" variants="no">Aggiunto a Evernote</translation>
    </message>
    <message>
        <source>Can&apos;t get notebook info.</source>
<translation type="unfinished" variants="no">Impossibile recuperare la nota.</translation>
    </message>
    <message>
        <source>Another note is still being added to Evernote. Please try again later.</source>
<translation type="unfinished" variants="no">Un&apos;altra nota è stata aggiunta a Evernote. Riprovare in seguito.</translation>
    </message>
    <message>
        <source>uploading...(%1% complete.)</source>
<translation type="unfinished" variants="no">caricamento...(%1% completato.)</translation>
    </message>
    <message>
        <source>Internet connection error. Please check your Wi-Fi setting.</source>
<translation type="unfinished" variants="no">Errore di connessione a internet. Controllare le impostazioni Wi-Fi.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Illegal name. Cannot be white space.</source>
<translation type="unfinished" variants="no">Il nome non può contenere solo spazi.</translation>
    </message>
    <message>
        <source>Illegal name. Cannot be blank.</source>
<translation type="unfinished" variants="no">Il campo del nome non può restare vuoto. Inserire un nome.</translation>
    </message>
    <message>
        <source>Invalid password!</source>
<translation type="unfinished" variants="no">La password è errata.</translation>
    </message>
    <message>
        <source>input name is not correct</source>
<translation type="unfinished" variants="no">Il nome è errato.</translation>
    </message>
    <message>
        <source>Not have enough space</source>
<translation type="unfinished" variants="no">Spazio insufficiente.</translation>
    </message>
</context>
<context>
    <name>SearchButtonWidgetNew</name>
    <message>
        <source>Close search result</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>Tag list</source>
<translation type="unfinished" variants="no">Elenco tag</translation>
    </message>
</context>
<context>
    <name>ENoteBook::MoveToViewItem</name>
    <message>
        <source>%1 pages total</source>
<translation type="unfinished" variants="no">%1 pagine</translation>
    </message>
</context>
<context>
    <name>ENoteBook::AddNoteItem</name>
    <message>
        <source>Add new note</source>
<translation type="unfinished" variants="no">Aggiungi nota</translation>
    </message>
</context>
</TS>
