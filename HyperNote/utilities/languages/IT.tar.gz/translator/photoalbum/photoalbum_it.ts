<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS []>
<TS version="2.0">
<context>
    <name>ENotePhoto::DeletePhotoDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this photo?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare questa foto?</translation>
    </message>
</context>
<context>
    <name>EnoteMessageBox</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ENotePhoto::ThumbBottomBar</name>
    <message>
        <source>No</source>
<translation type="unfinished" variants="no">No</translation>
    </message>
    <message>
        <source>Yes</source>
<translation type="unfinished" variants="no">Sì</translation>
    </message>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Enter</source>
<translation type="unfinished" variants="no">Entra</translation>
    </message>
    <message>
        <source>N - O</source>
<translation type="unfinished" variants="no">Nuovi-Prec.</translation>
    </message>
    <message>
        <source>O - N</source>
<translation type="unfinished" variants="no">Prec.-Nuovi</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>Delete</source>
<translation type="unfinished" variants="no">Elimina</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this photo?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare questa foto?</translation>
    </message>
    <message>
        <source>by Date</source>
<translation type="unfinished" variants="no">per data</translation>
    </message>
    <message>
        <source>by Name</source>
<translation type="unfinished" variants="no">per nome</translation>
    </message>
    <message>
        <source>Sort...</source>
<translation type="unfinished" variants="no">Ordina…</translation>
    </message>
    <message>
        <source>photoalbum</source>
<translation type="unfinished" variants="no">Album foto</translation>
    </message>
</context>
<context>
    <name>ReNameDialog</name>
    <message>
        <source>Ok</source>
<translation type="unfinished" variants="no">Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>The name already exist. </source>
<translation type="unfinished" variants="no">Il nome esiste già.</translation>
    </message>
    <message>
        <source>please input the name:</source>
<translation type="unfinished" variants="no">Inserire il nome:</translation>
    </message>
</context>
<context>
    <name>ENoteTagWidget::TagWidget</name>
    <message>
        <source>Add</source>
<translation type="unfinished" variants="no">Aggiungi</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Tag already exists</source>
<translation type="unfinished" variants="no">Il tag esiste già</translation>
    </message>
    <message>
        <source>Input Tag</source>
<translation type="unfinished" variants="no">Inserisci</translation>
    </message>
    <message>
        <source>Delete the tag:%1?</source>
<translation type="unfinished" variants="no">Eliminare il tag:%1?</translation>
    </message>
    <message>
        <source>Edit Tag</source>
<translation type="unfinished" variants="no">Modifica tag</translation>
    </message>
</context>
<context>
    <name>commonDlg::TagListWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Close search results</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>%1 items total</source>
<translation type="unfinished" variants="no">Totale di %1 elementi</translation>
    </message>
</context>
<context>
    <name>ENotePhoto::NameDialog</name>
    <message>
        <source>Name</source>
<translation type="unfinished" variants="no">Nome</translation>
    </message>
</context>
<context>
    <name>ENotePhoto::ThumbViewItem</name>
    <message>
        <source>Tag:</source>
<translation type="unfinished" variants="no">Tag:</translation>
    </message>
</context>
<context>
    <name>ImageEditorWidget</name>
    <message>
        <source>Paste</source>
<translation type="unfinished" variants="no">Incolla</translation>
    </message>
    <message>
        <source>Reset</source>
<translation type="unfinished" variants="no">Reset</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ENotePhoto::ImageViewWidget</name>
    <message>
        <source>Another file with the same name already exists. Please use another name, or delete the file in Recycle Bin</source>
<translation type="unfinished" variants="no">Esiste già un altro file con lo stesso nome. Scegliere un altro nome o eliminare il file nel cestino.</translation>
    </message>
    <message>
        <source>No search results.</source>
<translation type="unfinished" variants="no">La ricerca non ha prodotto alcun risultato.</translation>
    </message>
    <message>
        <source>Illegal name. Cannot contain \:/*?&quot;&lt;>|</source>
<translation type="unfinished" variants="no">Nome non valido. Il nome non può contenere \:/*?&quot;&lt;>|</translation>
    </message>
    <message>
        <source>Illegal name. Cannot be blank.</source>
<translation type="unfinished" variants="no">Il campo del nome non può restare vuoto. Inserire un nome.</translation>
    </message>
    <message>
        <source>photoview</source>
<translation type="unfinished" variants="no">Anteprima</translation>
    </message>
    <message>
        <source>Cannot find specified file. Please go to [Settings] - [Rescan for Media] and press [Execute] button to rescan for media</source>
<translation type="unfinished" variants="no">Impossibile trovare il file specificato. Andare a [Impostazioni] - [Ricerca file multimediali] e selezionare [Cerca] per cercare i file multimediali.</translation>
    </message>
</context>
<context>
    <name>ENotePhoto::PhotoThumbView</name>
    <message>
        <source>Another file with the same name already exists. Please use another name, or delete the file in Recycle Bin</source>
<translation type="unfinished" variants="no">Esiste già un altro file con lo stesso nome. Scegliere un altro nome o eliminare il file nel cestino.</translation>
    </message>
    <message>
        <source>No search results.</source>
<translation type="unfinished" variants="no">La ricerca non ha prodotto alcun risultato.</translation>
    </message>
    <message>
        <source>Illegal name. Cannot be blank.</source>
<translation type="unfinished" variants="no">Il campo del nome non può restare vuoto. Inserire un nome.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this photo?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare questa foto?</translation>
    </message>
    <message>
        <source>Cannot find specified file. Please go to [Settings] - [Rescan for Media] and press [Execute] button to rescan for media</source>
<translation type="unfinished" variants="no">Impossibile trovare il file specificato. Andare a [Impostazioni] - [Ricerca file multimediali] e selezionare [Cerca] per cercare i file multimediali.</translation>
    </message>
    <message>
        <source>Input the name</source>
<translation type="unfinished" variants="no">Inserire il nome</translation>
    </message>
    <message>
        <source>Illegal name. Cannot contain \:/*?&quot;&lt;>|.</source>
<translation type="unfinished" variants="no">Nome non valido. Il nome non può contenere \:/*?&quot;&lt;>|</translation>
    </message>
</context>
<context>
    <name>SearchButtonWidgetNew</name>
    <message>
        <source>Close search result</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>Tag list</source>
<translation type="unfinished" variants="no">Elenco tag</translation>
    </message>
</context>
<context>
    <name>ENotePhoto::PhotoSelectView</name>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Cannot open photos with size larger than 1MB or 5M pixels.</source>
<translation type="unfinished" variants="no">Impossibile visualizzare foto di dimensioni superiori a 1MB o a 5.0M pixel.</translation>
    </message>
    <message>
        <source>Cannot open this photo</source>
<translation type="unfinished" variants="no">Impossibile visualizzare questa foto.</translation>
    </message>
    <message>
        <source>Cannot find specified file. Please go to [Settings] - [Rescan for Media] and press [Execute] button to rescan for media</source>
<translation type="unfinished" variants="no">Impossibile trovare il file specificato. Andare a [Impostazioni] - [Ricerca file multimediali] e selezionare [Cerca] per cercare i file multimediali.</translation>
    </message>
    <message>
        <source>Only bmp, jpg, jpeg, gif, png formats are supported.</source>
<translation type="unfinished" variants="no">Sono supportati soltanto i seguenti formati:bmp, jpg, jpeg, gif e png.</translation>
    </message>
    <message>
        <source>Get ImageError!</source>
<translation type="unfinished" variants="no">Get Image Error!</translation>
    </message>
</context>
<context>
    <name>ENotePhoto::PhotoPopMenu</name>
    <message>
        <source>Delete</source>
<translation type="unfinished" variants="no">Elimina</translation>
    </message>
    <message>
        <source>Rename</source>
<translation type="unfinished" variants="no">Rinomina</translation>
    </message>
</context>
<context>
    <name>PhotoAlbum</name>
    <message>
        <source>Search</source>
<translation type="unfinished" variants="no">Cerca</translation>
    </message>
    <message>
        <source>photoview</source>
<translation type="unfinished" variants="no">Anteprima</translation>
    </message>
    <message>
        <source>photoalbum</source>
<translation type="unfinished" variants="no">Album foto</translation>
    </message>
    <message>
        <source>Photoalbum</source>
<translation type="unfinished" variants="no">Album foto</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Invalid password!</source>
<translation type="unfinished" variants="no">La password è errata.</translation>
    </message>
    <message>
        <source>Cannot open photos with size larger than 1MB or 5M pixels.</source>
<translation type="unfinished" variants="no">Impossibile visualizzare foto di dimensioni superiori a 1MB o a 5.0M pixel.</translation>
    </message>
    <message>
        <source>input name is not correct</source>
<translation type="unfinished" variants="no">Il nome è errato.</translation>
    </message>
    <message>
        <source>Cannot open this photo</source>
<translation type="unfinished" variants="no">Impossibile visualizzare questa foto.</translation>
    </message>
    <message>
        <source>Not have enough space</source>
<translation type="unfinished" variants="no">Spazio insufficiente.</translation>
    </message>
    <message>
        <source>Cannot find specified file. Please go to [Settings] - [Rescan for Media] and press [Execute] button to rescan for media</source>
<translation type="unfinished" variants="no">Impossibile trovare il file specificato. Andare a [Impostazioni] - [Ricerca file multimediali] e selezionare [Cerca] per cercare i file multimediali.</translation>
    </message>
    <message>
        <source>Only bmp, jpg, jpeg, gif, png formats are supported.</source>
<translation type="unfinished" variants="no">Sono supportati soltanto i seguenti formati:bmp, jpg, jpeg, gif e png.</translation>
    </message>
</context>
<context>
    <name>PhotoAlbumClass</name>
    <message>
        <source>PhotoAlbum</source>
<translation type="unfinished" variants="no">Album foto</translation>
    </message>
</context>
</TS>
