<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS []>
<TS version="2.0">
<context>
    <name>AboutDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>total</source>
<translation type="unfinished" variants="no">totale</translation>
    </message>
    <message>
        <source>About this device</source>
<translation type="unfinished" variants="no">Specifiche dispositivo</translation>
    </message>
    <message>
        <source>Boot loader version</source>
<translation type="unfinished" variants="no">Versione Bootloader</translation>
    </message>
    <message>
        <source>(Has no backup yet)</source>
<translation type="unfinished" variants="no">(ancora nessun backup)</translation>
    </message>
    <message>
        <source>Check details>></source>
<translation type="unfinished" variants="no">Controlla dettagli>></translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Enter device name.</source>
<translation type="unfinished" variants="no">Nome dispositivo</translation>
    </message>
    <message>
        <source>Device storage</source>
<translation type="unfinished" variants="no">Spazio archiviazione</translation>
    </message>
    <message>
        <source>Last backup</source>
<translation type="unfinished" variants="no">Ultimo backup</translation>
    </message>
    <message>
        <source>Software version</source>
<translation type="unfinished" variants="no">Versione software</translation>
    </message>
    <message>
        <source>SD card</source>
<translation type="unfinished" variants="no">Scheda SD</translation>
    </message>
    <message>
        <source>available</source>
<translation type="unfinished" variants="no">disponibile</translation>
    </message>
    <message>
        <source>Device name cannot be over 20 characters long.</source>
<translation type="unfinished" variants="no">Il nome del dispositivo deve contenere max.20 caratteri.</translation>
    </message>
    <message>
        <source>Device Name</source>
<translation type="unfinished" variants="no">Nome dispositivo</translation>
    </message>
    <message>
        <source>(Not available)</source>
<translation type="unfinished" variants="no">(non è inserita alcuna scheda SD)</translation>
    </message>
    <message>
        <source>Wi-Fi MAC address</source>
<translation type="unfinished" variants="no">Wi-Fi MAC address</translation>
    </message>
    <message>
        <source>Device ID</source>
<translation type="unfinished" variants="no">ID dispositivo</translation>
    </message>
</context>
<context>
    <name>AccountsDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Account name</source>
<translation type="unfinished" variants="no">Nome account</translation>
    </message>
    <message>
        <source>Show Password</source>
<translation type="unfinished" variants="no">Mostra password</translation>
    </message>
    <message>
        <source>Your password will be stored in the device.</source>
<translation type="unfinished" variants="no">La password sarà salvata nel dispositivo.</translation>
    </message>
    <message>
        <source>This device has been activated.</source>
<translation type="unfinished" variants="no">ID Adobe attivato! </translation>
    </message>
    <message>
        <source>Adobe ID server timed out. Please try again later.</source>
<translation type="unfinished" variants="no">Timeout del server ID Adobe. Riprovare in seguito.</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Logging into Evernote...</source>
<translation type="unfinished" variants="no">Accesso a Evernote…</translation>
    </message>
    <message>
        <source>Deactivate this device >></source>
<translation type="unfinished" variants="no">Disattiva l&apos;ID Adobe>></translation>
    </message>
    <message>
        <source>Evernote acount verified OK.</source>
<translation type="unfinished" variants="no">Account Evernote confermato.</translation>
    </message>
    <message>
        <source>This device has been activated. To use another ID, please deactivate first.</source>
<translation type="unfinished" variants="no">ID Adobe attivato! Per utilizzare un altro ID Adobe, disattivare questo.</translation>
    </message>
    <message>
        <source>Evernote server timed out. Please try again later.</source>
<translation type="unfinished" variants="no">Timeout del server Evernote. Riprovare in seguito.</translation>
    </message>
    <message>
        <source>You have logged in as %1.</source>
<translation type="unfinished" variants="no">Avete effettuato il login come %1.</translation>
    </message>
    <message>
        <source>Please select the account type:</source>
<translation type="unfinished" variants="no">Selezionare il tipo di account:</translation>
    </message>
    <message>
        <source>After deactivation, all books purchased with previous activation cannot be opened. Continue?</source>
<translation type="unfinished" variants="no">Dopo aver disattivato l&apos;ID Adobe, non sarà più possibile aprire i libri visualizzati in precedenza. Desiderate continuare?</translation>
    </message>
    <message>
        <source>Network connection error. Please check your Wi-Fi settings.</source>
<translation type="unfinished" variants="no">Errore di connessione alla rete.Controllare le impostazioni Wi-Fi.</translation>
    </message>
    <message>
        <source>Password</source>
<translation type="unfinished" variants="no">Password</translation>
    </message>
    <message>
        <source>Activating device...</source>
<translation type="unfinished" variants="no">Attivazione ID Adobe in corso…</translation>
    </message>
    <message>
        <source>Not activated. Need an ID? Apply one at
https://www.adobe.com/cfusion/membership/.
Please make sure time and timezone have been set.</source>
<translation type="unfinished" variants="no">Non attivato. Per l&apos;attivazione, è possibile richiedere un ID Adobe al seguente indirizzo: http://www.adobe.com/cfusion/membership/. Assicurarsi che sia stata impostata l&apos;ora e il fuso orario del dispositivo.</translation>
    </message>
    <message>
        <source>Adobe ID</source>
<translation type="unfinished" variants="no">ID Adobe</translation>
    </message>
    <message>
        <source>Not logged in yet. No account? Visit www.evernote.com to apply one.</source>
<translation type="unfinished" variants="no">Non avete ancora effettuato il login. Avete bisogno di un account? Visitate www.evernote.com e registratevi.</translation>
    </message>
    <message>
        <source>Please enter account name and password.</source>
<translation type="unfinished" variants="no">Inserire il nome account e la password.</translation>
    </message>
    <message>
        <source>Cloud service accounts</source>
<translation type="unfinished" variants="no">Servizio Cloud</translation>
    </message>
    <message>
        <source>Evernote account</source>
<translation type="unfinished" variants="no">Account Evernote</translation>
    </message>
</context>
<context>
    <name>CalibrationDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Reset to factory default.</source>
<translation type="unfinished" variants="no">Ripristino delle impostazioni di fabbrica.</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Pen personalizatin. Please use your normal gesture when doing the calibration, and make sure you hit the center of the crosses with precision.</source>
<translation type="unfinished" variants="no">Calibrazione della penna. Per la calibrazione, utilizzare la penna Wacom e premere sul simbolo della croce [+] che appare sullo schermo (Nota: per una calibrazione ottimale, impugnare la penna nel modo in cui si tiene normalmente per scrivere).</translation>
    </message>
    <message>
        <source>Please chose one of the followings:</source>
<translation type="unfinished" variants="no">Selezionare una delle seguenti opzioni:</translation>
    </message>
    <message>
        <source>Personalize your pen</source>
<translation type="unfinished" variants="no">Personalizza penna</translation>
    </message>
    <message>
        <source>Finished pen personalization.</source>
<translation type="unfinished" variants="no">Calibrazione penna riuscita.</translation>
    </message>
    <message>
        <source>Reset complete.</source>
<translation type="unfinished" variants="no">Ripristino dispositivo riuscito.</translation>
    </message>
    <message>
        <source>Resetting...</source>
<translation type="unfinished" variants="no">Ripristino in corso…</translation>
    </message>
</context>
<context>
    <name>DisplayDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ENoteBook::TemplateDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>EnoteMessageBox</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>KeylockDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Lock</source>
<translation type="unfinished" variants="no">Blocca</translation>
    </message>
    <message>
        <source>Note:</source>
<translation type="unfinished" variants="no">Nota:</translation>
    </message>
    <message>
        <source>Lock sensor keys when enter an application:</source>
<translation type="unfinished" variants="no">Blocco sensore tasti quando entra una domanda:</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Unlock</source>
<translation type="unfinished" variants="no">Sblocca</translation>
    </message>
    <message>
        <source>Reader:</source>
<translation type="unfinished" variants="no">Reader:</translation>
    </message>
    <message>
        <source>Key Lock</source>
<translation type="unfinished" variants="no">Key Lock</translation>
    </message>
</context>
<context>
    <name>LanguageDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Language</source>
<translation type="unfinished" variants="no">Lingua</translation>
    </message>
    <message>
        <source>Traditional Chiness</source>
<translation type="unfinished" variants="no">Chiness tradizionale</translation>
    </message>
    <message>
        <source>English</source>
<translation type="unfinished" variants="no">Inglese</translation>
    </message>
</context>
<context>
    <name>MessageDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>NoticeDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
</context>
<context>
    <name>PowerDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Auto stand-by</source>
<translation type="unfinished" variants="no">Sospensione automatica</translation>
    </message>
    <message>
        <source>Never (Press power key to turn off screen)</source>
<translation type="unfinished" variants="no">Mai (premere il pulsante di accensione per disattivare lo schermo)</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>30 minutes idle</source>
<translation type="unfinished" variants="no">30 minuti di inattività</translation>
    </message>
    <message>
        <source>15 minutes idle</source>
<translation type="unfinished" variants="no">15 minuti di inattività</translation>
    </message>
    <message>
        <source>5 minutes idle</source>
<translation type="unfinished" variants="no">5 minuti di inattività</translation>
    </message>
    <message>
        <source>Turn off screen after:</source>
<translation type="unfinished" variants="no">Disattivare lo schermo dopo:</translation>
    </message>
</context>
<context>
    <name>RecoveryDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Enter password:</source>
<translation type="unfinished" variants="no">Inserire la password:</translation>
    </message>
    <message>
        <source>Deleting contents and resetting...</source>
<translation type="unfinished" variants="no">Eliminare il contenuto ed avviare il ripristino...</translation>
    </message>
    <message>
        <source>This will delete all the contents and settings. You cannot revert the process. Continue?</source>
<translation type="unfinished" variants="no">Il processo di ripristino elimina in modo permanente tutti i dati del dispositivo, che non potranno più essere recuperati in seguito. Desiderate continuare?</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Invalid password.</source>
<translation type="unfinished" variants="no">Password non valida.</translation>
    </message>
    <message>
        <source>Press [OK] to restart the device.</source>
<translation type="unfinished" variants="no">Premere [OK] per riavviare il dispositivo. </translation>
    </message>
</context>
<context>
    <name>SecurityDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Show Password</source>
<translation type="unfinished" variants="no">Mostra password</translation>
    </message>
    <message>
        <source>Please enter new password again in &quot;Affirm password&quot;.</source>
<translation type="unfinished" variants="no">Nel campo [Conferma password], inserire di nuovo la password per conferma.</translation>
    </message>
    <message>
        <source>Please enter new password.</source>
<translation type="unfinished" variants="no">Inserire la nuova password.</translation>
    </message>
    <message>
        <source>Please enter current password.</source>
<translation type="unfinished" variants="no">Inserire la password attualmente in uso.</translation>
    </message>
    <message>
        <source>Wrong password. Please enter again.</source>
<translation type="unfinished" variants="no">Password errata. Inserire di nuovo la password.</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Require password when wakeup</source>
<translation type="unfinished" variants="no">Inserisci password alla riattivazione</translation>
    </message>
    <message>
        <source>Affirm Password</source>
<translation type="unfinished" variants="no">Conferma pwd</translation>
    </message>
    <message>
        <source>This password is used for unlocking the screen, notes, and books.</source>
<translation type="unfinished" variants="no">La password è utilizzata per sbloccare schermo, note e libri.</translation>
    </message>
    <message>
        <source>Please note your password. You will not be able to retrieve it when lost.</source>
<translation type="unfinished" variants="no">Annotare a parte la password, per poterla facilmente ritrovare in seguito.</translation>
    </message>
    <message>
        <source>Password</source>
<translation type="unfinished" variants="no">Password</translation>
    </message>
    <message>
        <source>Please enter password.</source>
<translation type="unfinished" variants="no">Inserire la password.</translation>
    </message>
    <message>
        <source>Security</source>
<translation type="unfinished" variants="no">Protezione</translation>
    </message>
    <message>
        <source>New Password</source>
<translation type="unfinished" variants="no">Nuova Password</translation>
    </message>
    <message>
        <source>Please use same passwords in both &quot;New password&quot; and &quot;Affirm password&quot;</source>
<translation type="unfinished" variants="no">Nel campo [Conferma password], inserire di nuovo la password per conferma.</translation>
    </message>
</context>
<context>
    <name>SoundDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>VkbLanguageDlg</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Keyboard Language</source>
<translation type="unfinished" variants="no">Lingua tastiera</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Zhuyin</source>
<translation type="unfinished" variants="no">Zhuyin</translation>
    </message>
    <message>
        <source>Hand input</source>
<translation type="unfinished" variants="no">Mano d&apos;ingresso</translation>
    </message>
    <message>
        <source>English(Default)</source>
<translation type="unfinished" variants="no">Inglese (default)</translation>
    </message>
    <message>
        <source>Russian</source>
<translation type="unfinished" variants="no">Russo</translation>
    </message>
</context>
<context>
    <name>ReNameDialog</name>
    <message>
        <source>Ok</source>
<translation type="unfinished" variants="no">Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>The name already exist. </source>
<translation type="unfinished" variants="no">Il nome esiste già.</translation>
    </message>
    <message>
        <source>please input the name:</source>
<translation type="unfinished" variants="no">Inserire il nome:</translation>
    </message>
</context>
<context>
    <name>ENoteTagWidget::TagWidget</name>
    <message>
        <source>Add</source>
<translation type="unfinished" variants="no">Aggiungi</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Tag already exists</source>
<translation type="unfinished" variants="no">Il tag esiste già</translation>
    </message>
    <message>
        <source>Input Tag</source>
<translation type="unfinished" variants="no">Inserisci</translation>
    </message>
    <message>
        <source>Delete the tag:%1?</source>
<translation type="unfinished" variants="no">Eliminare il tag:%1?</translation>
    </message>
    <message>
        <source>Edit Tag</source>
<translation type="unfinished" variants="no">Modifica tag</translation>
    </message>
</context>
<context>
    <name>Setting</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>Lock</source>
<translation type="unfinished" variants="no">Blocca</translation>
    </message>
    <message>
        <source>Reset</source>
<translation type="unfinished" variants="no">Reset</translation>
    </message>
    <message>
        <source>About this device</source>
<translation type="unfinished" variants="no">Specifiche dispositivo</translation>
    </message>
    <message>
        <source>Wi-Fi networks</source>
<translation type="unfinished" variants="no">Reti Wi-Fi</translation>
    </message>
    <message>
        <source>Need to reboot the system.</source>
<translation type="unfinished" variants="no">Necessità di riavviare il sistema.</translation>
    </message>
    <message>
        <source>Reset to factory default</source>
<translation type="unfinished" variants="no">Ripristino predefiniti</translation>
    </message>
    <message>
        <source>Current setting: Always on</source>
<translation type="unfinished" variants="no">Impostazione attuale: sempre acceso</translation>
    </message>
    <message>
        <source>Auto stand-by</source>
<translation type="unfinished" variants="no">Sospensione automatica</translation>
    </message>
    <message>
        <source>Keyboard Language</source>
<translation type="unfinished" variants="no">Lingua tastiera</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>Choose</source>
<translation type="unfinished" variants="no">Seleziona</translation>
    </message>
    <message>
        <source>Note: </source>
<translation type="unfinished" variants="no">Nota:</translation>
    </message>
    <message>
        <source>Adobe ID:</source>
<translation type="unfinished" variants="no">ID Adobe:</translation>
    </message>
    <message>
        <source>Set up</source>
<translation type="unfinished" variants="no">Configura</translation>
    </message>
    <message>
        <source>Unlock</source>
<translation type="unfinished" variants="no">Sblocca</translation>
    </message>
    <message>
        <source>Current setting: Turn off after idling for %1 minutes</source>
<translation type="unfinished" variants="no">Impostazione attuale:spegni dopo %1 minuti di inattività.</translation>
    </message>
    <message>
        <source>Zhuyin</source>
<translation type="unfinished" variants="no">Zhuyin</translation>
    </message>
    <message>
        <source>Hand input</source>
<translation type="unfinished" variants="no">Mano d&apos;ingresso</translation>
    </message>
    <message>
        <source>Personalize your pen.</source>
<translation type="unfinished" variants="no">Ripristino delle impostazioni predefinite o calibrazione della penna.</translation>
    </message>
    <message>
        <source>Legal information</source>
<translation type="unfinished" variants="no">Termini di utilizzo</translation>
    </message>
    <message>
        <source>Default note background</source>
<translation type="unfinished" variants="no">Sfondo predef. nota</translation>
    </message>
    <message>
        <source>Language</source>
<translation type="unfinished" variants="no">Lingua</translation>
    </message>
    <message>
        <source>Re-scan</source>
<translation type="unfinished" variants="no">Cerca</translation>
    </message>
    <message>
        <source>English(Default)</source>
<translation type="unfinished" variants="no">Inglese (default)</translation>
    </message>
    <message>
        <source>Personalize your pen</source>
<translation type="unfinished" variants="no">Personalizza penna</translation>
    </message>
    <message>
        <source>Russian</source>
<translation type="unfinished" variants="no">Russo</translation>
    </message>
    <message>
        <source>Delete all contents and reset the device to factory defaults.</source>
<translation type="unfinished" variants="no">Elimina tutti i contenuti e ripristina le impostazioni predefinite.</translation>
    </message>
    <message>
        <source>Details</source>
<translation type="unfinished" variants="no">Dettagli</translation>
    </message>
    <message>
        <source>Reader: </source>
<translation type="unfinished" variants="no">Reader:</translation>
    </message>
    <message>
        <source>Security</source>
<translation type="unfinished" variants="no">Protezione</translation>
    </message>
    <message>
        <source>Traditional Chiness</source>
<translation type="unfinished" variants="no">Chiness tradizionale</translation>
    </message>
    <message>
        <source>English</source>
<translation type="unfinished" variants="no">Inglese</translation>
    </message>
    <message>
        <source>Key Lock</source>
<translation type="unfinished" variants="no">Key Lock</translation>
    </message>
    <message>
        <source>Settings</source>
<translation type="unfinished" variants="no">Impostazioni</translation>
    </message>
    <message>
        <source>User aggrements and copyright information</source>
<translation type="unfinished" variants="no">Termini di utilizzo e informazioni sui diritti d&apos;autore</translation>
    </message>
    <message>
        <source>Evernote account:</source>
<translation type="unfinished" variants="no">Account Evernote:</translation>
    </message>
    <message>
        <source>Configure and connect to Wi-Fi networks.</source>
<translation type="unfinished" variants="no">Configurazione e connessione con reti Wi-Fi.</translation>
    </message>
    <message>
        <source>Re-scan device storage and SD card for media.</source>
<translation type="unfinished" variants="no">Scansione dispositivo e scheda SD per la ricerca di file multimediali.</translation>
    </message>
    <message>
        <source>Re-scan for media</source>
<translation type="unfinished" variants="no">Ricerca file multimediali</translation>
    </message>
    <message>
        <source>(has not been set)</source>
<translation type="unfinished" variants="no">(non configurato)</translation>
    </message>
    <message>
        <source>Cloud service accounts</source>
<translation type="unfinished" variants="no">Servizio Cloud</translation>
    </message>
    <message>
        <source>Date and Time</source>
<translation type="unfinished" variants="no">Data e ora</translation>
    </message>
    <message>
        <source>Set the passcode to access the device and lock / unlock the contents.</source>
<translation type="unfinished" variants="no">Impostare il codice di protezione per accedere al dispositivo e bloccare/sbloccare i contenuti.</translation>
    </message>
</context>
<context>
    <name>commonDlg::TagListWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Close search results</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>%1 items total</source>
<translation type="unfinished" variants="no">Totale di %1 elementi</translation>
    </message>
</context>
<context>
    <name>ENoteBook::TemplateViewItem</name>
    <message>
        <source>Designed by </source>
<translation type="unfinished" variants="no">Realizzato da </translation>
    </message>
    <message>
        <source>Daily calories</source>
<translation type="unfinished" variants="no">Diario della dieta giornaliera</translation>
    </message>
    <message>
        <source>Blank</source>
<translation type="unfinished" variants="no">Bianco</translation>
    </message>
    <message>
        <source>Todai Vertical Wide</source>
<translation type="unfinished" variants="no">Protocollo Todai verticale esp.</translation>
    </message>
    <message>
        <source>Todai Wide Ruled</source>
<translation type="unfinished" variants="no">Protocollo Todai espanso</translation>
    </message>
    <message>
        <source>Calendar month with note</source>
<translation type="unfinished" variants="no">Calendario mensile con note</translation>
    </message>
    <message>
        <source>Graph (multi-weight)</source>
<translation type="unfinished" variants="no">Carta millim.(multi-weight)</translation>
    </message>
    <message>
        <source>Month in a page</source>
<translation type="unfinished" variants="no">Calendario mensile</translation>
    </message>
    <message>
        <source>Cover page I</source>
<translation type="unfinished" variants="no">Copertina I</translation>
    </message>
    <message>
        <source>Cornell Notes</source>
<translation type="unfinished" variants="no">Blocco note Cornell</translation>
    </message>
    <message>
        <source>Todai College Ruled</source>
<translation type="unfinished" variants="no">Protocollo Todai normale</translation>
    </message>
    <message>
        <source>Caligraphy paper</source>
<translation type="unfinished" variants="no">Fogli stile libero</translation>
    </message>
    <message>
        <source>Table of Contents I</source>
<translation type="unfinished" variants="no">Tabella I</translation>
    </message>
    <message>
        <source>Table of Contents II</source>
<translation type="unfinished" variants="no">Tabella II</translation>
    </message>
    <message>
        <source>2011 Yearly</source>
<translation type="unfinished" variants="no">Calendario 2011</translation>
    </message>
    <message>
        <source>2012 Yearly</source>
<translation type="unfinished" variants="no">Calendario 2012</translation>
    </message>
    <message>
        <source>Contacts</source>
<translation type="unfinished" variants="no">Contatti</translation>
    </message>
    <message>
        <source>Dot grid</source>
<translation type="unfinished" variants="no">Foglio puntinato</translation>
    </message>
    <message>
        <source>Axonometric</source>
<translation type="unfinished" variants="no">Assonometrica</translation>
    </message>
    <message>
        <source>Day agenda</source>
<translation type="unfinished" variants="no">Agenda giornaliera</translation>
    </message>
    <message>
        <source>Wide Ruled</source>
<translation type="unfinished" variants="no">Protocollo espanso</translation>
    </message>
    <message>
        <source>Pie chart</source>
<translation type="unfinished" variants="no">Grafico a torta</translation>
    </message>
    <message>
        <source>Vertical (Extra Wide)</source>
<translation type="unfinished" variants="no">Protocollo verticale extra</translation>
    </message>
    <message>
        <source>Electricity tracker</source>
<translation type="unfinished" variants="no">Electricity Record</translation>
    </message>
    <message>
        <source>Todai Vertical</source>
<translation type="unfinished" variants="no">Protocollo Todai verticale</translation>
    </message>
    <message>
        <source>Quad graph with note</source>
<translation type="unfinished" variants="no">Assonom. millim. con note</translation>
    </message>
    <message>
        <source>Graph paper</source>
<translation type="unfinished" variants="no">Carta millimetrata</translation>
    </message>
    <message>
        <source>To-do list</source>
<translation type="unfinished" variants="no">Agenda</translation>
    </message>
    <message>
        <source>Vertical (Wide)</source>
<translation type="unfinished" variants="no">Protocollo verticale espanso</translation>
    </message>
    <message>
        <source>Weekly agenda</source>
<translation type="unfinished" variants="no">Agenda settimanale</translation>
    </message>
    <message>
        <source>Verticle Ruled</source>
<translation type="unfinished" variants="no">Protocollo verticale</translation>
    </message>
    <message>
        <source>Cover page II</source>
<translation type="unfinished" variants="no">Copertina II</translation>
    </message>
    <message>
        <source>Quad graph paper</source>
<translation type="unfinished" variants="no">Assonometrica millimetrata</translation>
    </message>
    <message>
        <source>Blank (bordered)</source>
<translation type="unfinished" variants="no">Bianco con bordi</translation>
    </message>
    <message>
        <source>College Ruled</source>
<translation type="unfinished" variants="no">Protocollo normale</translation>
    </message>
    <message>
        <source>Vertical Blocks</source>
<translation type="unfinished" variants="no">Quadretti verticali</translation>
    </message>
    <message>
        <source>Block paper</source>
<translation type="unfinished" variants="no">Foglio a quadretti</translation>
    </message>
    <message>
        <source>Expense tracker</source>
<translation type="unfinished" variants="no">Libro mastro</translation>
    </message>
    <message>
        <source>Week in a page</source>
<translation type="unfinished" variants="no">Calendario settimanale</translation>
    </message>
    <message>
        <source>Four squares</source>
<translation type="unfinished" variants="no">Quattro quadrati</translation>
    </message>
    <message>
        <source>Log-log (two decades)</source>
<translation type="unfinished" variants="no">Diagramma a due assi</translation>
    </message>
    <message>
        <source>Contact card</source>
<translation type="unfinished" variants="no">Biglietto da visita</translation>
    </message>
    <message>
        <source>Double Spaced</source>
<translation type="unfinished" variants="no">Doppia spaziatura</translation>
    </message>
</context>
<context>
    <name>StorageDlg</name>
    <message>
        <source>Books</source>
<translation type="unfinished" variants="no">Libri</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Music</source>
<translation type="unfinished" variants="no">Musica</translation>
    </message>
    <message>
        <source>Notes</source>
<translation type="unfinished" variants="no">Note</translation>
    </message>
    <message>
        <source>Photos</source>
<translation type="unfinished" variants="no">Foto</translation>
    </message>
    <message>
        <source>Device storage</source>
<translation type="unfinished" variants="no">Spazio archiviazione</translation>
    </message>
    <message>
        <source>Voice Memos</source>
<translation type="unfinished" variants="no">Promemoria vocali</translation>
    </message>
    <message>
        <source>SD card</source>
<translation type="unfinished" variants="no">Scheda SD</translation>
    </message>
</context>
<context>
    <name>LegalInfoDlg</name>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Legal Information</source>
<translation type="unfinished" variants="no">Termini di utilizzo</translation>
    </message>
</context>
<context>
    <name>ImageEditorWidget</name>
    <message>
        <source>Paste</source>
<translation type="unfinished" variants="no">Incolla</translation>
    </message>
    <message>
        <source>Reset</source>
<translation type="unfinished" variants="no">Reset</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>SearchButtonWidgetNew</name>
    <message>
        <source>Close search result</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>Tag list</source>
<translation type="unfinished" variants="no">Elenco tag</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Invalid password!</source>
<translation type="unfinished" variants="no">La password è errata.</translation>
    </message>
    <message>
        <source>input name is not correct</source>
<translation type="unfinished" variants="no">Il nome è errato.</translation>
    </message>
    <message>
        <source>Not have enough space</source>
<translation type="unfinished" variants="no">Spazio insufficiente.</translation>
    </message>
</context>
<context>
    <name>EverNoteVerifyThread</name>
    <message>
        <source>Network connection error. Please check your Wi-Fi settings.</source>
<translation type="unfinished" variants="no">Errore di connessione alla rete.Controllare le impostazioni Wi-Fi.</translation>
    </message>
    <message>
        <source>Wrong ID or password. Please input again.</source>
<translation type="unfinished" variants="no">ID o password errata. Controllare le impostazioni Wi-Fi.</translation>
    </message>
    <message>
        <source>Unknow error, please check your evernote account.</source>
<translation type="unfinished" variants="no">Errore sconosciuto.Controllare l&apos;account Evernote.</translation>
    </message>
</context>
</TS>
