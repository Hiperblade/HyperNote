<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS []>
<TS version="2.0">
<context>
    <name>EnoteMessageBox</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ReNameDialog</name>
    <message>
        <source>Ok</source>
<translation type="unfinished" variants="no">Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>The name already exist. </source>
<translation type="unfinished" variants="no">Il nome esiste già.</translation>
    </message>
    <message>
        <source>please input the name:</source>
<translation type="unfinished" variants="no">Inserire il nome:</translation>
    </message>
</context>
<context>
    <name>ENoteTagWidget::TagWidget</name>
    <message>
        <source>Add</source>
<translation type="unfinished" variants="no">Aggiungi</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Tag already exists</source>
<translation type="unfinished" variants="no">Il tag esiste già</translation>
    </message>
    <message>
        <source>Input Tag</source>
<translation type="unfinished" variants="no">Inserisci</translation>
    </message>
    <message>
        <source>Delete the tag:%1?</source>
<translation type="unfinished" variants="no">Eliminare il tag:%1?</translation>
    </message>
    <message>
        <source>Edit Tag</source>
<translation type="unfinished" variants="no">Modifica tag</translation>
    </message>
</context>
<context>
    <name>SelectUSBMode</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>Enter</source>
<translation type="unfinished" variants="no">Entra</translation>
    </message>
    <message>
        <source>SD Card Reader mode stopped. It&apos;s possible that the SD card is ejected. Please insert the SD card, unplug the USB cord, and connect the USB cord again.</source>
<translation type="unfinished" variants="no">La modalità Lettore di Schede SD è stata disattivata.E&apos; possibile rimuovere la scheda SD.Per riattivare la modalità Lettore di Schede SD, inserire di nuovo la scheda SD, disconnettere e poi riconnettere il cavo USB.</translation>
    </message>
    <message>
        <source>Enter SD Card Reader Mode</source>
<translation type="unfinished" variants="no">Accesso alla modalità Lettore di Schede SD</translation>
    </message>
    <message>
        <source>All the applications must be close before connecting. Your data will be safely saved. Continue?</source>
<translation type="unfinished" variants="no">Prima della connessione, saranno chiuse tutte le applicazioni in esecuzione.Desiderate continuare?</translation>
    </message>
    <message>
        <source>USB Mode Selection</source>
<translation type="unfinished" variants="no">Selezione della modalità USB</translation>
    </message>
    <message>
        <source>Eee Note Sync connected!</source>
<translation type="unfinished" variants="no">Eee Note Sync connesso!</translation>
    </message>
    <message>
        <source>Datebase Sync complete. After work,you can unplug the USB.</source>
<translation type="unfinished" variants="no">Sincronizzazione database completata.Per disattivare la modalità Eee Note Sync, disconnettere il cavo USB.</translation>
    </message>
    <message>
        <source>Scanning SD card...</source>
<translation type="unfinished" variants="no">Scansione scheda SD…</translation>
    </message>
    <message>
        <source>Eee Note Sync Mode</source>
<translation type="unfinished" variants="no">Modalità Eee Note Sync</translation>
    </message>
    <message>
        <source>Windows PC Digitizer Mode</source>
<translation type="unfinished" variants="no">Modalità Tavoletta Grafica per Windows PC</translation>
    </message>
    <message>
        <source>Install Eee Note Sync Software</source>
<translation type="unfinished" variants="no">Installazione di Eee Note Sync</translation>
    </message>
    <message>
        <source>Datebase Sync...Please don&apos;t unplug the USB.</source>
<translation type="unfinished" variants="no">Sincronizzazione database in corso…Non disconnettere il cavo USB.</translation>
    </message>
    <message>
        <source>Installation mode running...(Find the installer using Windows Explorer.)</source>
<translation type="unfinished" variants="no">Dal desktop del computer, selezionare Computer > Eee Note Sync Installer, individuare setup.exe e cliccare due volte sul file da installare.</translation>
    </message>
    <message>
        <source>Wait for Eee Note Sync connecting...</source>
<translation type="unfinished" variants="no">Attendere la connessione con Eee Note Sync…</translation>
    </message>
    <message>
        <source>Digitizer Mode running...(right-hand side)</source>
<translation type="unfinished" variants="no">Modalità Tavoletta Grafica (lato destro) in corso...</translation>
    </message>
    <message>
        <source>SD Card Reader running...Please do not eject SD card.</source>
<translation type="unfinished" variants="no">E&apos; in corso la lettura della scheda SD. Non rimuovere la scheda durante la lettura dei dati.</translation>
    </message>
    <message>
        <source>Digitizer Mode running...(left-hand side)</source>
<translation type="unfinished" variants="no">Modalità Tavoletta Grafica (lato sinistro) in corso...</translation>
    </message>
</context>
<context>
    <name>commonDlg::TagListWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Close search results</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>%1 items total</source>
<translation type="unfinished" variants="no">Totale di %1 elementi</translation>
    </message>
</context>
<context>
    <name>ListViewItem</name>
    <message>
        <source>Install Required Software for the computer</source>
<translation type="unfinished" variants="no">Eee Note Sync e driver per tavoletta grafica</translation>
    </message>
    <message>
        <source>Select this, and follow the instruction on the computer to install Eee Note Sync software and pen tablet driver.</source>
<translation type="unfinished" variants="no">Seguire le istruzioni sul computer per installare Eee Note Sync e il driver per l&apos;uso di Eee Note come tavoletta grafica.</translation>
    </message>
    <message>
        <source>(SD card does not exist)</source>
<translation type="unfinished" variants="no">(Scheda SD non inserita)</translation>
    </message>
    <message>
        <source>Enter SD Card Reader Mode</source>
<translation type="unfinished" variants="no">Accesso alla modalità Lettore di Schede SD</translation>
    </message>
    <message>
        <source>Eee Note Sync Mode</source>
<translation type="unfinished" variants="no">Modalità Eee Note Sync</translation>
    </message>
    <message>
        <source>Select this mode to install the Eee Note Sync software.</source>
<translation type="unfinished" variants="no">Selezionare questa modalità per installare Eee Note Sync.</translation>
    </message>
    <message>
        <source>Windows PC Digitizer Mode</source>
<translation type="unfinished" variants="no">Modalità Tavoletta Grafica per Windows PC</translation>
    </message>
    <message>
        <source>Manage your content using Eee Note Sync software. Please install the software first.</source>
<translation type="unfinished" variants="no">Installare Eee Note Sync prima di utilizzare questa utilità per la gestione di file.</translation>
    </message>
    <message>
        <source>Use the digitizer on the right-hand side of the computer with USB connector facing left.</source>
<translation type="unfinished" variants="no">Utilizzare la tavoletta grafica digitale sul lato destro del computer con il connettore USB rivolto verso sinistra.</translation>
    </message>
    <message>
        <source>Access your SD card via PC, Please make sure the SD card is inserted.</source>
<translation type="unfinished" variants="no">In questa modalità, prima di accedere alla scheda SD via computer, assicurarsi che la scheda SD sia correttamente inserita.</translation>
    </message>
    <message utf8="true">
        <source>Use Eee Note as a wacom pen tablet on a Microsoft Windows PC. You need to install the driver first with “Install Required Software”.</source>
<translation type="unfinished" variants="no">Per installare il driver, selezionare [Installa Software].</translation>
    </message>
    <message>
        <source>Use the digitizer on the left-hand side of the computer with USB connector facing right.</source>
<translation type="unfinished" variants="no">Utilizzare la tavoletta grafica digitale sul lato sinistro del computer con il connettore USB rivolto verso destra.</translation>
    </message>
    <message>
        <source>Digitizer Mode (left-hand side)</source>
<translation type="unfinished" variants="no">Modalità Tavoletta Grafica (lato sinistro)</translation>
    </message>
    <message>
        <source>Install Eee Note Sync Software</source>
<translation type="unfinished" variants="no">Installazione di Eee Note Sync</translation>
    </message>
    <message>
        <source>Charge Mode</source>
<translation type="unfinished" variants="no">Modalità Eee Note</translation>
    </message>
    <message>
        <source>Digitizer Mode (right-hand side)</source>
<translation type="unfinished" variants="no">Modalità  Tavoletta Grafica (lato destro)</translation>
    </message>
    <message>
        <source>Use Eee Note as a Microsoft Windows compatible digitizer.</source>
<translation type="unfinished" variants="no">Utilizzare Eee Note come tavoletta grafica digitale compatibile con Microsoft Windows.</translation>
    </message>
    <message>
        <source>Choose this mode to charge and continue using the device.</source>
<translation type="unfinished" variants="no">Selezionare questa modalità per ricaricare il dispositivo quando è acceso.</translation>
    </message>
</context>
<context>
    <name>ImageEditorWidget</name>
    <message>
        <source>Paste</source>
<translation type="unfinished" variants="no">Incolla</translation>
    </message>
    <message>
        <source>Reset</source>
<translation type="unfinished" variants="no">Reset</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>SearchButtonWidgetNew</name>
    <message>
        <source>Close search result</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>Tag list</source>
<translation type="unfinished" variants="no">Elenco tag</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Invalid password!</source>
<translation type="unfinished" variants="no">La password è errata.</translation>
    </message>
    <message>
        <source>input name is not correct</source>
<translation type="unfinished" variants="no">Il nome è errato.</translation>
    </message>
    <message>
        <source>Not have enough space</source>
<translation type="unfinished" variants="no">Spazio insufficiente.</translation>
    </message>
</context>
</TS>
