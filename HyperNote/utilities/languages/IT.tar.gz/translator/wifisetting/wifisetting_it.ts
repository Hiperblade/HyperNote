<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS []>
<TS version="2.0">
<context>
    <name>EnoteMessageBox</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ReNameDialog</name>
    <message>
        <source>Ok</source>
<translation type="unfinished" variants="no">Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>The name already exist. </source>
<translation type="unfinished" variants="no">Il nome esiste già.</translation>
    </message>
    <message>
        <source>please input the name:</source>
<translation type="unfinished" variants="no">Inserire il nome:</translation>
    </message>
</context>
<context>
    <name>ENoteTagWidget::TagWidget</name>
    <message>
        <source>Add</source>
<translation type="unfinished" variants="no">Aggiungi</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Tag already exists</source>
<translation type="unfinished" variants="no">Il tag esiste già</translation>
    </message>
    <message>
        <source>Input Tag</source>
<translation type="unfinished" variants="no">Inserisci</translation>
    </message>
    <message>
        <source>Delete the tag:%1?</source>
<translation type="unfinished" variants="no">Eliminare il tag:%1?</translation>
    </message>
    <message>
        <source>Edit Tag</source>
<translation type="unfinished" variants="no">Modifica tag</translation>
    </message>
</context>
<context>
    <name>NetworkConfig</name>
    <message>
        <source>Try</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>WEP</source>
<translation type="unfinished" variants="no">WEP</translation>
    </message>
    <message>
        <source>None</source>
<translation type="unfinished" variants="no">Nessuna</translation>
    </message>
    <message>
        <source>SSID</source>
<translation type="unfinished" variants="no">SSID</translation>
    </message>
    <message>
        <source>TKIP</source>
<translation type="unfinished" variants="no">TKIP</translation>
    </message>
    <message>
        <source>Save</source>
<translation type="unfinished" variants="no">Salva</translation>
    </message>
    <message>
        <source>connecting...</source>
<translation type="unfinished" variants="no">Connessione...</translation>
    </message>
    <message>
        <source>The network is remembered.</source>
<translation type="unfinished" variants="no">Rete salvata!</translation>
    </message>
    <message>
        <source>Authentication</source>
<translation type="unfinished" variants="no">Autenticazione</translation>
    </message>
    <message>
        <source>Fail to get IP,please check and retry!</source>
<translation type="unfinished" variants="no">Errore nel ricevimento dell&apos;indirizzo IP.Controllare
le impostazioni di rete o del server DHCP e riprovare.</translation>
    </message>
    <message>
        <source>Plaintext (open / no authentication)</source>
<translation type="unfinished" variants="no">Plain-text (aperta / nessuna autenticazione)</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>The WEP password needs to be 5 or 13 ascii characters,
 or 10 or 26 hexadecimal characters.</source>
<translation type="unfinished" variants="no">La password WEP deve contenere 5 o 13 caratteri
ASCII oppure 10 o 26 caratteri esadecimali.</translation>
    </message>
    <message>
        <source>SSID length should be in 1~32.</source>
<translation type="unfinished" variants="no">Il nome di rete (SSID) deve contenere 
da 1 a 32 caratteri.</translation>
    </message>
    <message>
        <source>WPA-Personal (PSK)</source>
<translation type="unfinished" variants="no">WPA-Personal (PSK)</translation>
    </message>
    <message>
        <source>Password</source>
<translation type="unfinished" variants="no">Password</translation>
    </message>
    <message>
        <source>Password error or fail to get IP!</source>
<translation type="unfinished" variants="no">Impossibile stabilire la connessione alla rete.
Controllare le impostazioni di crittografia e la password. </translation>
    </message>
    <message>
        <source>Couldn&apos;t find this network ,please check your config!</source>
<translation type="unfinished" variants="no">Impossibile trovare la rete. 
Controllare il nome di rete.</translation>
    </message>
    <message>
        <source>Encryption</source>
<translation type="unfinished" variants="no">Crittografia</translation>
    </message>
    <message>
        <source>Connect</source>
<translation type="unfinished" variants="no">Connetti</translation>
    </message>
    <message>
        <source>Couldn&apos;t connect this network ,
please check your password or authentication!</source>
<translation type="unfinished" variants="no">Impossibile trovare la rete.Controllare 
le impostazioni di crittografia e la password. </translation>
    </message>
    <message>
        <source>Connected even the network is not broadcasting</source>
<translation type="unfinished" variants="no">Connetti a una rete nascosta</translation>
    </message>
    <message>
        <source>Static WEP (no authentication)</source>
<translation type="unfinished" variants="no">WEP statico (nessuna autenticazione)</translation>
    </message>
    <message>
        <source>WPA-PSK requires a passphrase of
 8 to 63 characters or 64 hex digit PSK.</source>
<translation type="unfinished" variants="no">Il codice di protezione WPA-PSK deve
contenere da 8 a 63 caratteri o 64 cifre esadecimali.</translation>
    </message>
    <message>
        <source>try to connect...</source>
<translation type="unfinished" variants="no">Tentativo di connessione...</translation>
    </message>
</context>
<context>
    <name>NetworkConfigFast</name>
    <message>
        <source>Try</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>connecting...</source>
<translation type="unfinished" variants="no">Connessione...</translation>
    </message>
    <message>
        <source>Cannot connect to selected network. 
Please check your password and authentication settings..</source>
<translation type="unfinished" variants="no">Impossibile stabilire la connessione con la rete selezionata.
Controllare le impostazioni di rete e la password.</translation>
    </message>
    <message>
        <source>Cannot find selected network.
 Please check your network settings.</source>
<translation type="unfinished" variants="no">Impossibile trovare la rete selezionata. 
Controllare le impostazioni di rete.</translation>
    </message>
    <message>
        <source>Cannot get IP address. 
Please check your network settings and try again.</source>
<translation type="unfinished" variants="no">Impossibile ricevere un indirizzo IP.
Controllare le impostazioni di rete e riprovare.</translation>
    </message>
    <message>
        <source>Cannot connect to selected network.
Please check your password and authentication settings.</source>
<translation type="unfinished" variants="no">Impossibile stabilire la connessione con la rete selezionata.
Controllare le impostazioni di rete e la password.</translation>
    </message>
    <message>
        <source>The WEP password needs to be 5 or 13 ascii characters,
 or 10 or 26 hexadecimal characters.</source>
<translation type="unfinished" variants="no">La password WEP deve contenere 5 o 13 caratteri
ASCII oppure 10 o 26 caratteri esadecimali.</translation>
    </message>
    <message>
        <source>Profile is saved.</source>
<translation type="unfinished" variants="no">Profilo W-Fi salvato!</translation>
    </message>
    <message>
        <source>WPA-PSK requires a passphrase of
 8 to 63 characters or 64 hex digit PSK.</source>
<translation type="unfinished" variants="no">Il codice di protezione WPA-PSK deve
contenere da 8 a 63 caratteri o 64 cifre esadecimali.</translation>
    </message>
    <message>
        <source>Cannot find selected network. 
Please check your network settings.</source>
<translation type="unfinished" variants="no">Impossibile trovare la rete selezionata. 
Controllare le impostazioni di rete.</translation>
    </message>
    <message>
        <source>try to connect...</source>
<translation type="unfinished" variants="no">Tentativo di connessione...</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>None</source>
<translation type="unfinished" variants="no">Nessuna</translation>
    </message>
    <message>
        <source>SSID</source>
<translation type="unfinished" variants="no">SSID</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Show Password</source>
<translation type="unfinished" variants="no">Mostra password</translation>
    </message>
    <message>
        <source>Wifi Profile</source>
<translation type="unfinished" variants="no">Profilo Wi-Fi</translation>
    </message>
    <message>
        <source>Authentication</source>
<translation type="unfinished" variants="no">Autenticazione</translation>
    </message>
    <message>
        <source>Plaintext (open / no authentication)</source>
<translation type="unfinished" variants="no">Plain-text (aperta / nessuna autenticazione)</translation>
    </message>
    <message>
        <source>Profile Manager>></source>
<translation type="unfinished" variants="no">Gestione Profili>></translation>
    </message>
    <message>
        <source>Wifi Information</source>
<translation type="unfinished" variants="no">Impostazioni Wi-Fi</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Connect to this network even when the SSID is not being broadcasted.</source>
<translation type="unfinished" variants="no">Connetti a questa rete anche se nascosta.</translation>
    </message>
    <message>
        <source>Open Key</source>
<translation type="unfinished" variants="no">Chiave aperta</translation>
    </message>
    <message>
        <source>WPA-Personal (PSK)</source>
<translation type="unfinished" variants="no">WPA-Personal (PSK)</translation>
    </message>
    <message>
        <source>Invalid password!</source>
<translation type="unfinished" variants="no">La password è errata.</translation>
    </message>
    <message>
        <source>Share Key</source>
<translation type="unfinished" variants="no">Chiave condivisa</translation>
    </message>
    <message>
        <source>Password</source>
<translation type="unfinished" variants="no">Password</translation>
    </message>
    <message>
        <source>input name is not correct</source>
<translation type="unfinished" variants="no">Il nome è errato.</translation>
    </message>
    <message>
        <source>WifiSetting</source>
<translation type="unfinished" variants="no">Impostazioni Wi-Fi</translation>
    </message>
    <message>
        <source>Encryption</source>
<translation type="unfinished" variants="no">Crittografia</translation>
    </message>
    <message>
        <source>Connect</source>
<translation type="unfinished" variants="no">Connetti</translation>
    </message>
    <message>
        <source>Not have enough space</source>
<translation type="unfinished" variants="no">Spazio insufficiente.</translation>
    </message>
    <message>
        <source>Key Index</source>
<translation type="unfinished" variants="no">Indice chiavi</translation>
    </message>
    <message>
        <source>Static WEP (no authentication)</source>
<translation type="unfinished" variants="no">WEP statico (nessuna autenticazione)</translation>
    </message>
    <message>
        <source>Wifi List</source>
<translation type="unfinished" variants="no">Elenco Wi-Fi</translation>
    </message>
    <message>
        <source>Static WEP (Shared Key authentication)</source>
<translation type="unfinished" variants="no">WEP statico (autenticazione con chiave già condivisa)</translation>
    </message>
    <message>
        <source>WPA2-Personal (PSK)</source>
<translation type="unfinished" variants="no">WPA2-Personal (PSK)</translation>
    </message>
</context>
<context>
    <name>commonDlg::TagListWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Close search results</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>%1 items total</source>
<translation type="unfinished" variants="no">Totale di %1 elementi</translation>
    </message>
</context>
<context>
    <name>WifiSettingClass</name>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Connected</source>
<translation type="unfinished" variants="no">Connesso</translation>
    </message>
    <message>
        <source>Refresh</source>
<translation type="unfinished" variants="no">Aggiorna</translation>
    </message>
    <message>
        <source>WifiSetting</source>
<translation type="unfinished" variants="no">Impostazioni Wi-Fi</translation>
    </message>
    <message>
        <source>Disconnect</source>
<translation type="unfinished" variants="no">Disconnetti</translation>
    </message>
</context>
<context>
    <name>ImageEditorWidget</name>
    <message>
        <source>Paste</source>
<translation type="unfinished" variants="no">Incolla</translation>
    </message>
    <message>
        <source>Reset</source>
<translation type="unfinished" variants="no">Reset</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>WifiSetting</name>
    <message>
        <source>This authentication can&apos;t be supported!
</source>
<translation type="unfinished" variants="no">Questo metodo di autenticazione non è supportato.
</translation>
    </message>
    <message>
        <source>Scanning...</source>
<translation type="unfinished" variants="no">Ricerca…</translation>
    </message>
    <message>
        <source>Wifi Setting</source>
<translation type="unfinished" variants="no">Impostazioni Wi-Fi</translation>
    </message>
</context>
<context>
    <name>WifiProfile</name>
    <message>
        <source>Are you sure you want to delete the profile?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare questo profilo?</translation>
    </message>
</context>
<context>
    <name>SearchButtonWidgetNew</name>
    <message>
        <source>Close search result</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>Tag list</source>
<translation type="unfinished" variants="no">Elenco tag</translation>
    </message>
</context>
<context>
    <name>ProfilePopMenu</name>
    <message>
        <source>Move Up</source>
<translation type="unfinished" variants="no">Sposta su</translation>
    </message>
    <message>
        <source>Delete</source>
<translation type="unfinished" variants="no">Elimina</translation>
    </message>
    <message>
        <source>Move Down</source>
<translation type="unfinished" variants="no">Sposta giù</translation>
    </message>
</context>
<context>
    <name>QObject::QObject</name>
    <message>
        <source>Encryption</source>
<translation type="unfinished" variants="no">Crittografia</translation>
    </message>
</context>
</TS>
