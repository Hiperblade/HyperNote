<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS []>
<TS version="2.0">
<context>
    <name>EnoteMessageBox</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ReNameDialog</name>
    <message>
        <source>Ok</source>
<translation type="unfinished" variants="no">Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>The name already exist. </source>
<translation type="unfinished" variants="no">Il nome esiste già.</translation>
    </message>
    <message>
        <source>please input the name:</source>
<translation type="unfinished" variants="no">Inserire il nome:</translation>
    </message>
</context>
<context>
    <name>ENoteTagWidget::TagWidget</name>
    <message>
        <source>Add</source>
<translation type="unfinished" variants="no">Aggiungi</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Tag already exists</source>
<translation type="unfinished" variants="no">Il tag esiste già</translation>
    </message>
    <message>
        <source>Input Tag</source>
<translation type="unfinished" variants="no">Inserisci</translation>
    </message>
    <message>
        <source>Delete the tag:%1?</source>
<translation type="unfinished" variants="no">Eliminare il tag:%1?</translation>
    </message>
    <message>
        <source>Edit Tag</source>
<translation type="unfinished" variants="no">Modifica tag</translation>
    </message>
</context>
<context>
    <name>ENoteBook::ViewListWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Enter</source>
<translation type="unfinished" variants="no">Entra</translation>
    </message>
    <message>
        <source>N - O</source>
<translation type="unfinished" variants="no">Nuovi-Prec.</translation>
    </message>
    <message>
        <source>O - N</source>
<translation type="unfinished" variants="no">Prec.-Nuovi</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Search all (name A to Z)</source>
<translation type="unfinished" variants="no">Cerca tutto (ordine alfabetico [A - Z])</translation>
    </message>
    <message>
        <source>Search Everything</source>
<translation type="unfinished" variants="no">Cerca tutto</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>Recent</source>
<translation type="unfinished" variants="no">Recenti</translation>
    </message>
    <message>
        <source>by Date</source>
<translation type="unfinished" variants="no">per data</translation>
    </message>
    <message>
        <source>by Name</source>
<translation type="unfinished" variants="no">per nome</translation>
    </message>
    <message>
        <source>Searching...</source>
<translation type="unfinished" variants="no">Ricerca in corso...</translation>
    </message>
    <message>
        <source>Search all (date aesc.)</source>
<translation type="unfinished" variants="no">Cerca tutto (ordine cronologico)</translation>
    </message>
    <message>
        <source>Search all (date desc.)</source>
<translation type="unfinished" variants="no">Cerca tutto (ordine cronolog. inverso)</translation>
    </message>
    <message>
        <source>Search all (name Z to A)</source>
<translation type="unfinished" variants="no">Cerca tutto (ordine alfabetico [Z - A])</translation>
    </message>
</context>
<context>
    <name>commonDlg::TagListWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Close search results</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>%1 items total</source>
<translation type="unfinished" variants="no">Totale di %1 elementi</translation>
    </message>
</context>
<context>
    <name>TitleBar</name>
    <message>
        <source>Close search results</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
</context>
<context>
    <name>ENoteBook::ListViewItem</name>
    <message>
        <source>Music Player</source>
<translation type="unfinished" variants="no">Lettore musicale</translation>
    </message>
    <message>
        <source>Notes</source>
<translation type="unfinished" variants="no">Note</translation>
    </message>
    <message>
        <source>Photo Album</source>
<translation type="unfinished" variants="no">Album foto</translation>
    </message>
    <message>
        <source>%1 voice memos total</source>
<translation type="unfinished" variants="no">%1 promemoria vocali</translation>
    </message>
    <message>
        <source>Bubble Breaker</source>
<translation type="unfinished" variants="no">Bubble Breaker</translation>
    </message>
    <message>
        <source>%1 photos total</source>
<translation type="unfinished" variants="no">%1 foto</translation>
    </message>
    <message>
        <source>Sticky Memo</source>
<translation type="unfinished" variants="no">Memo testuali</translation>
    </message>
    <message>
        <source>%1 contacts total</source>
<translation type="unfinished" variants="no">%1 Contatti</translation>
    </message>
    <message>
        <source>Camera</source>
<translation type="unfinished" variants="no">Fotocamera</translation>
    </message>
    <message>
        <source>Reader</source>
<translation type="unfinished" variants="no">Reader</translation>
    </message>
    <message>
        <source>Sudoku</source>
<translation type="unfinished" variants="no">Sudoku</translation>
    </message>
    <message>
        <source>%1 music total</source>
<translation type="unfinished" variants="no">%1 brani</translation>
    </message>
    <message>
        <source>%1 notes total</source>
<translation type="unfinished" variants="no">%1 note</translation>
    </message>
    <message>
        <source>%1 books total</source>
<translation type="unfinished" variants="no">%1 libri</translation>
    </message>
    <message>
        <source>PhoneBook</source>
<translation type="unfinished" variants="no">Rubrica</translation>
    </message>
    <message>
        <source>Trash Bin</source>
<translation type="unfinished" variants="no">Cestino</translation>
    </message>
    <message>
        <source>Voice Memo</source>
<translation type="unfinished" variants="no">Memo vocali</translation>
    </message>
    <message>
        <source>%1 deleted items total</source>
<translation type="unfinished" variants="no">%1 elementi eliminati</translation>
    </message>
    <message>
        <source>Setting</source>
<translation type="unfinished" variants="no">Impostazioni</translation>
    </message>
    <message>
        <source>Web Browser</source>
<translation type="unfinished" variants="no">Browser web</translation>
    </message>
    <message>
        <source>Calculator</source>
<translation type="unfinished" variants="no">Calcolatrice</translation>
    </message>
    <message>
        <source>Dictionary</source>
<translation type="unfinished" variants="no">Dizionario</translation>
    </message>
    <message>
        <source>To Do List</source>
<translation type="unfinished" variants="no">Agenda</translation>
    </message>
    <message>
        <source>%1 text memos total</source>
<translation type="unfinished" variants="no">%1 promemoria</translation>
    </message>
    <message>
        <source>Experimental</source>
<translation type="unfinished" variants="no">Sperimentale</translation>
    </message>
</context>
<context>
    <name>ImageEditorWidget</name>
    <message>
        <source>Paste</source>
<translation type="unfinished" variants="no">Incolla</translation>
    </message>
    <message>
        <source>Reset</source>
<translation type="unfinished" variants="no">Reset</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ENoteBook::SearchViewItem</name>
    <message>
        <source>Tag: </source>
<translation type="unfinished" variants="no">Tag:</translation>
    </message>
    <message>
        <source>Tags: </source>
<translation type="unfinished" variants="no">Tag:</translation>
    </message>
</context>
<context>
    <name>ENoteBook::SearchView</name>
    <message>
        <source>No search results.</source>
<translation type="unfinished" variants="no">La ricerca non ha prodotto alcun risultato.</translation>
    </message>
</context>
<context>
    <name>SearchButtonWidgetNew</name>
    <message>
        <source>Close search result</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>Tag list</source>
<translation type="unfinished" variants="no">Elenco tag</translation>
    </message>
</context>
<context>
    <name>ENoteBook::VMController</name>
    <message>
        <source>Please input password:</source>
<translation type="unfinished" variants="no">Password:</translation>
    </message>
    <message>
        <source>Invalid password.</source>
<translation type="unfinished" variants="no">Password non valida.</translation>
    </message>
    <message>
        <source>Cannot find specified file. Please go to [Settings] - [Rescan for Media] and press [Execute] button to rescan for media files.</source>
<translation type="unfinished" variants="no">Impossibile trovare il file specificato. Andare a [Impostazioni] - [Ricerca file multimediali] e selezionare [Cerca] per cercare i file multimediali.</translation>
    </message>
    <message>
        <source>No supported format!</source>
<translation type="unfinished" variants="no">Impossibile aprire il file.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Invalid password!</source>
<translation type="unfinished" variants="no">La password è errata.</translation>
    </message>
    <message>
        <source>input name is not correct</source>
<translation type="unfinished" variants="no">Il nome è errato.</translation>
    </message>
    <message>
        <source>Not have enough space</source>
<translation type="unfinished" variants="no">Spazio insufficiente.</translation>
    </message>
</context>
</TS>
