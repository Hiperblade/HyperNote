<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS []>
<TS version="2.0">
<context>
    <name>EnoteMessageBox</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ebook::MarkPanel</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
</context>
<context>
    <name>ReNameDialog</name>
    <message>
        <source>Ok</source>
<translation type="unfinished" variants="no">Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>The name already exist. </source>
<translation type="unfinished" variants="no">Il nome esiste già.</translation>
    </message>
    <message>
        <source>please input the name:</source>
<translation type="unfinished" variants="no">Inserire il nome:</translation>
    </message>
</context>
<context>
    <name>ENoteTagWidget::TagWidget</name>
    <message>
        <source>Add</source>
<translation type="unfinished" variants="no">Aggiungi</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Tag already exists</source>
<translation type="unfinished" variants="no">Il tag esiste già</translation>
    </message>
    <message>
        <source>Input Tag</source>
<translation type="unfinished" variants="no">Inserisci</translation>
    </message>
    <message>
        <source>Delete the tag:%1?</source>
<translation type="unfinished" variants="no">Eliminare il tag:%1?</translation>
    </message>
    <message>
        <source>Edit Tag</source>
<translation type="unfinished" variants="no">Modifica tag</translation>
    </message>
</context>
<context>
    <name>ebook::ReaderMainWindow</name>
    <message>
        <source>Pen</source>
<translation type="unfinished" variants="no">Penna</translation>
    </message>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>Zoom</source>
<translation type="unfinished" variants="no">Zoom</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Go to</source>
<translation type="unfinished" variants="no">Vai a</translation>
    </message>
    <message>
        <source>Sorry! Can not get content of this page.</source>
<translation type="unfinished" variants="no">Impossibile aprire questa pagina. Eseguire di nuovo il download del libro.</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>Eraser</source>
<translation type="unfinished" variants="no">Gomma</translation>
    </message>
    <message>
        <source>Page percentage</source>
<translation type="unfinished" variants="no">Percentuale letta</translation>
    </message>
    <message>
        <source>Remark</source>
<translation type="unfinished" variants="no">Strumenti</translation>
    </message>
    <message>
        <source>Bookmark</source>
<translation type="unfinished" variants="no">Segnalibro</translation>
    </message>
    <message>
        <source>Annotation lists</source>
<translation type="unfinished" variants="no">Annotazioni</translation>
    </message>
    <message>
        <source>Not enough space. Please delete some files and try again.</source>
<translation type="unfinished" variants="no">Spazio insufficiente. Eliminare alcuni file, svuotare il cestino e riprovare.</translation>
    </message>
    <message>
        <source>Remark lists</source>
<translation type="unfinished" variants="no">Frasi di rilievo</translation>
    </message>
    <message>
        <source>Page exported as /photo/%1 in your SD card.</source>
<translation type="unfinished" variants="no">Pagina esportate come /foto/%1 nella scheda SD.</translation>
    </message>
    <message>
        <source>Click the &apos;Back&apos; button to return to the Normal Mode.</source>
<translation type="unfinished" variants="no">Fare clic sul pulsante &apos;Indietro&apos; per tornare alla modalità normale.</translation>
    </message>
    <message>
        <source>Bookmark lists</source>
<translation type="unfinished" variants="no">Segnalibri</translation>
    </message>
    <message>
        <source>Table of content</source>
<translation type="unfinished" variants="no">Sommario</translation>
    </message>
    <message>
        <source>Page exported as /eTablet/var/photo/%1 in your internal memory space.</source>
<translation type="unfinished" variants="no">Pagina esportati come /eTablet/var/foto/%1 nel vostro spazio di memoria interna.</translation>
    </message>
    <message>
        <source>Sorry! Can not open this book!</source>
<translation type="unfinished" variants="no">Impossibile aprire questo libro.</translation>
    </message>
    <message>
        <source>Highlight</source>
<translation type="unfinished" variants="no">Evidenziatore</translation>
    </message>
    <message>
        <source>Print Screen ...</source>
<translation type="unfinished" variants="no">Acquisizione schermo...</translation>
    </message>
</context>
<context>
    <name>ENoteBook::SearchViewItem</name>
    <message>
        <source>Tag</source>
<translation type="unfinished" variants="no">Tag</translation>
    </message>
    <message>
        <source>Author</source>
<translation type="unfinished" variants="no">Autore</translation>
    </message>
</context>
<context>
    <name>MenuBar</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Enter</source>
<translation type="unfinished" variants="no">Entra</translation>
    </message>
    <message>
        <source>N - O</source>
<translation type="unfinished" variants="no">Nuovi-Prec.</translation>
    </message>
    <message>
        <source>O - N</source>
<translation type="unfinished" variants="no">Prec.-Nuovi</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>by Date</source>
<translation type="unfinished" variants="no">per data</translation>
    </message>
    <message>
        <source>by Name</source>
<translation type="unfinished" variants="no">per nome</translation>
    </message>
    <message>
        <source>Sort...</source>
<translation type="unfinished" variants="no">Ordina…</translation>
    </message>
</context>
<context>
    <name>commonDlg::TagListWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Close search results</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>%1 items total</source>
<translation type="unfinished" variants="no">Totale di %1 elementi</translation>
    </message>
</context>
<context>
    <name>ENoteBook::EBookPopMenuItem</name>
    <message>
        <source>Lock</source>
<translation type="unfinished" variants="no">Blocca</translation>
    </message>
    <message>
        <source>Delete</source>
<translation type="unfinished" variants="no">Elimina</translation>
    </message>
    <message>
        <source>Rename</source>
<translation type="unfinished" variants="no">Rinomina</translation>
    </message>
    <message>
        <source>Unlock</source>
<translation type="unfinished" variants="no">Sblocca</translation>
    </message>
</context>
<context>
    <name>ebook::DownWindow</name>
    <message>
        <source>Open</source>
<translation type="unfinished" variants="no">Apri</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>The book is already on this machine.</source>
<translation type="unfinished" variants="no">Questo libro è già presente nel dispositivo.</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>download failed</source>
<translation type="unfinished" variants="no">Download non riuscito.</translation>
    </message>
    <message>
        <source>downloading...</source>
<translation type="unfinished" variants="no">Download in corso…</translation>
    </message>
    <message>
        <source>Successfully downloaded</source>
<translation type="unfinished" variants="no">Download riuscito!</translation>
    </message>
</context>
<context>
    <name>ebook::CAnnotationPanel</name>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this annotation?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare questa annotazione?</translation>
    </message>
</context>
<context>
    <name>ebook::MarkWindow</name>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>No Bookmark.</source>
<translation type="unfinished" variants="no">Nessun segnalibro.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this remark?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare le frasi evidenziate?</translation>
    </message>
    <message>
        <source>No Table Of Content.</source>
<translation type="unfinished" variants="no">Nessun sommario.</translation>
    </message>
    <message>
        <source>No Remark.</source>
<translation type="unfinished" variants="no">Nessuna frase evidenziata.</translation>
    </message>
    <message>
        <source>No Annotation.</source>
<translation type="unfinished" variants="no">Nessuna annotazione.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this bookmark?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare questo segnalibro?</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this annotation?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare questa annotazione?</translation>
    </message>
</context>
<context>
    <name>ImageEditorWidget</name>
    <message>
        <source>Paste</source>
<translation type="unfinished" variants="no">Incolla</translation>
    </message>
    <message>
        <source>Reset</source>
<translation type="unfinished" variants="no">Reset</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ebook::BookstoreList</name>
    <message>
        <source>close</source>
<translation type="unfinished" variants="no">chiudi</translation>
    </message>
</context>
<context>
    <name>ENoteBook::VMController</name>
    <message>
        <source>Enter password:</source>
<translation type="unfinished" variants="no">Inserire la password:</translation>
    </message>
    <message>
        <source>Invalid password</source>
<translation type="unfinished" variants="no">Password non valida</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this book &quot;%1&quot;?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare il libro&quot;%1&quot;?</translation>
    </message>
    <message>
        <source>Cannot find specified file. Please go to [Settings] - [Rescan for Media] and press [Execute] button to rescan for media files.</source>
<translation type="unfinished" variants="no">Impossibile trovare il file specificato. Andare a [Impostazioni] - [Ricerca file multimediali] e selezionare [Cerca] per cercare i file multimediali.</translation>
    </message>
    <message>
        <source>Input the name</source>
<translation type="unfinished" variants="no">Inserire il nome</translation>
    </message>
    <message>
        <source>You have not assigned a security password. Please go to [Settings] - [Security] and create a password, and use the password to proceed.</source>
<translation type="unfinished" variants="no">Non è stata ancora assegnata una password di protezione.Andare a [Impostazioni] - [Protezione] e creare una password, quindi utilizzare la password per procedere.</translation>
    </message>
</context>
<context>
    <name>ENoteBook::SearchView</name>
    <message>
        <source>No search results.</source>
<translation type="unfinished" variants="no">La ricerca non ha prodotto alcun risultato.</translation>
    </message>
    <message>
        <source>No books.</source>
<translation type="unfinished" variants="no">Non è stato trovato nessun libro.</translation>
    </message>
</context>
<context>
    <name>ENoteBook::AddBookItem</name>
    <message>
        <source>Buy more books...</source>
<translation type="unfinished" variants="no">Acquista libri online</translation>
    </message>
    <message>
        <source>Buy books from our selected onlines bookstores using our web browser.</source>
<translation type="unfinished" variants="no">Utilizzare il browser web per acquistare altri libri disponibili online.</translation>
    </message>
</context>
<context>
    <name>ebook::SelectWidget</name>
    <message>
        <source>Please select a word.</source>
<translation type="unfinished" variants="no">Si prega di selezionare una parola.</translation>
    </message>
    <message>
        <source>Please click to select a paragraph.</source>
<translation type="unfinished" variants="no">Selezionare un paragrafo.</translation>
    </message>
    <message>
        <source>Use &apos;hand&apos; icon to drag the page.</source>
<translation type="unfinished" variants="no">icona &apos;mano&apos; per trascinare la pagina.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Illegal name. Cannot be white space.</source>
<translation type="unfinished" variants="no">Il nome non può contenere solo spazi.</translation>
    </message>
    <message>
        <source>Illegal name. Cannot be blank.</source>
<translation type="unfinished" variants="no">Il campo del nome non può restare vuoto. Inserire un nome.</translation>
    </message>
    <message>
        <source>Invalid password!</source>
<translation type="unfinished" variants="no">La password è errata.</translation>
    </message>
    <message>
        <source>input name is not correct</source>
<translation type="unfinished" variants="no">Il nome è errato.</translation>
    </message>
    <message>
        <source>Sorry!Can not open this book!</source>
<translation type="unfinished" variants="no">Impossibile aprire il libro. Eseguire di nuovo il download del libro.</translation>
    </message>
    <message>
        <source>Not have enough space</source>
<translation type="unfinished" variants="no">Spazio insufficiente.</translation>
    </message>
</context>
<context>
    <name>SearchButtonWidgetNew</name>
    <message>
        <source>Close search result</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>Tag list</source>
<translation type="unfinished" variants="no">Elenco tag</translation>
    </message>
</context>
<context>
    <name>ENoteBook::DeleteDialog</name>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Are you sure to delete the %1</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare questo elemento?</translation>
    </message>
</context>
<context>
    <name>ENoteBook::ViewListWidget</name>
    <message>
        <source>Search</source>
<translation type="unfinished" variants="no">Cerca</translation>
    </message>
</context>
<context>
    <name>ViewListWidgetClass</name>
    <message>
        <source>Book List</source>
<translation type="unfinished" variants="no">Libri</translation>
    </message>
</context>
<context>
    <name>WidgetMan</name>
    <message>
        <source>Book List</source>
<translation type="unfinished" variants="no">Libri</translation>
    </message>
</context>
<context>
    <name>ebook::BookmarkListItem</name>
    <message>
        <source>Page %1</source>
<translation type="unfinished" variants="no">Pagina %1</translation>
    </message>
</context>
<context>
    <name>ebook::RemarkListItem</name>
    <message>
        <source>Page %1</source>
<translation type="unfinished" variants="no">Pagina %1</translation>
    </message>
</context>
<context>
    <name>ebook::DrmFunc</name>
    <message>
        <source>File %1 does not exist.</source>
<translation type="unfinished" variants="no">Il file %1  non esiste.</translation>
    </message>
    <message>
        <source>File %1 has wrong format.</source>
<translation type="unfinished" variants="no">Il formato del file %1 è errato.</translation>
    </message>
    <message>
        <source>Not enough space on device storage. Please delete some files, clean up Recycle Bin, and try again.</source>
<translation type="unfinished" variants="no">Spazio libero insufficiente. Eliminare alcuni file, svuotare il cestino e riprovare.</translation>
    </message>
</context>
<context>
    <name>ebook::DrmMan</name>
    <message>
        <source>Cannot download. Please go to [Settings] - [Accounts] and set Adobe Account.</source>
<translation type="unfinished" variants="no">Impossibile aprire libri protetti da DRM. Andare a [Impostazioni] - [Servizio Cloud] per impostare il proprio ID Adobe.</translation>
    </message>
</context>
</TS>
