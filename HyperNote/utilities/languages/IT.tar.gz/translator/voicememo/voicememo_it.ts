<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS []>
<TS version="2.0">
<context>
    <name>EnoteMessageBox</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ReNameDialog</name>
    <message>
        <source>Ok</source>
<translation type="unfinished" variants="no">Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>The name already exist. </source>
<translation type="unfinished" variants="no">Il nome esiste già.</translation>
    </message>
    <message>
        <source>please input the name:</source>
<translation type="unfinished" variants="no">Inserire il nome:</translation>
    </message>
</context>
<context>
    <name>ENoteTagWidget::TagWidget</name>
    <message>
        <source>Add</source>
<translation type="unfinished" variants="no">Aggiungi</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Tag already exists</source>
<translation type="unfinished" variants="no">Il tag esiste già</translation>
    </message>
    <message>
        <source>Input Tag</source>
<translation type="unfinished" variants="no">Inserisci</translation>
    </message>
    <message>
        <source>Delete the tag:%1?</source>
<translation type="unfinished" variants="no">Eliminare il tag:%1?</translation>
    </message>
    <message>
        <source>Edit Tag</source>
<translation type="unfinished" variants="no">Modifica tag</translation>
    </message>
</context>
<context>
    <name>ENoteVoiceMemo::MainDialog</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>Voice memo player</source>
<translation type="unfinished" variants="no">Lettore di promemoria vocali.</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Enter</source>
<translation type="unfinished" variants="no">Entra</translation>
    </message>
    <message>
        <source>N - O</source>
<translation type="unfinished" variants="no">Nuovi-Prec.</translation>
    </message>
    <message>
        <source>O - N</source>
<translation type="unfinished" variants="no">Prec.-Nuovi</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>&quot;erecord&quot; process does not start up!</source>
<translation type="unfinished" variants="no">&quot;Erecord&quot; processo non si avvia!</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>Search</source>
<translation type="unfinished" variants="no">Cerca</translation>
    </message>
    <message>
        <source>New Voice memo</source>
<translation type="unfinished" variants="no">Nuovo promemoria vocale</translation>
    </message>
    <message>
        <source>Voice memos</source>
<translation type="unfinished" variants="no">Memo vocali</translation>
    </message>
    <message>
        <source>by Date</source>
<translation type="unfinished" variants="no">per data</translation>
    </message>
    <message>
        <source>by Name</source>
<translation type="unfinished" variants="no">per nome</translation>
    </message>
    <message>
        <source>Sort...</source>
<translation type="unfinished" variants="no">Ordina…</translation>
    </message>
    <message>
        <source>Cannot find specified file. Please go to [Settings] - [Rescan for Media] and press [Execute] button to rescan for media files.</source>
<translation type="unfinished" variants="no">Impossibile trovare il file specificato. Andare a [Impostazioni] - [Ricerca file multimediali] e selezionare [Cerca] per cercare i file multimediali.</translation>
    </message>
    <message>
        <source>Loading...</source>
<translation type="unfinished" variants="no">Caricamento...</translation>
    </message>
    <message>
        <source>Please stop playing music before playing Voice memos. (You can do so by clicking the blinking icon on the status bar above.)</source>
<translation type="unfinished" variants="no">Prima di riprodurre un file musicale, interrompere il promemoria vocale. Per interrompere un file musicale, cliccare sull&apos;icona lampeggiante nella barra degli strumenti.</translation>
    </message>
    <message>
        <source>No enough space to record!</source>
<translation type="unfinished" variants="no">Spazio insufficiente per la registrazione di promemoria vocali. Eliminare alcuni file, svuotare il cestino e riprovare.</translation>
    </message>
</context>
<context>
    <name>ENoteVoiceMemo::PlayDialog</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Next</source>
<translation type="unfinished" variants="no">Successivo</translation>
    </message>
    <message>
        <source>Play</source>
<translation type="unfinished" variants="no">Riproduci</translation>
    </message>
    <message>
        <source>Stop</source>
<translation type="unfinished" variants="no">Interrompi</translation>
    </message>
    <message>
        <source>Voice memo player</source>
<translation type="unfinished" variants="no">Lettore di promemoria vocali.</translation>
    </message>
    <message>
        <source>Pause</source>
<translation type="unfinished" variants="no">Pausa</translation>
    </message>
    <message>
        <source>Another file with the same name already exists. Please use another name, or delete the file in Recycle Bin</source>
<translation type="unfinished" variants="no">Esiste già un altro file con lo stesso nome. Scegliere un altro nome o eliminare il file nel cestino.</translation>
    </message>
    <message>
        <source>No search results.</source>
<translation type="unfinished" variants="no">La ricerca non ha prodotto alcun risultato.</translation>
    </message>
    <message>
        <source>Illegal name. Cannot contain \:/*?&quot;&lt;>|</source>
<translation type="unfinished" variants="no">Nome non valido. Il nome non può contenere \:/*?&quot;&lt;>|</translation>
    </message>
    <message>
        <source>Illegal name. Cannot be blank.</source>
<translation type="unfinished" variants="no">Il campo del nome non può restare vuoto. Inserire un nome.</translation>
    </message>
    <message>
        <source>Song Name: </source>
<translation type="unfinished" variants="no">Nome del brano:</translation>
    </message>
    <message>
        <source>Previous</source>
<translation type="unfinished" variants="no">Precedente</translation>
    </message>
    <message>
        <source>Cannot find specified file. Please go to [Settings] - [Rescan for Media] and press [Execute] button to rescan for media files.</source>
<translation type="unfinished" variants="no">Impossibile trovare il file specificato. Andare a [Impostazioni] - [Ricerca file multimediali] e selezionare [Cerca] per cercare i file multimediali.</translation>
    </message>
    <message>
        <source>SD card is pulled up, stop music!</source>
<translation type="unfinished" variants="no">Il file musicale è stato improvvisamente interrotto a seguito della rimozione della scheda SD.</translation>
    </message>
</context>
<context>
    <name>ENoteVoiceMemo::RecordDialog</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>Play</source>
<translation type="unfinished" variants="no">Riproduci</translation>
    </message>
    <message>
        <source>Save</source>
<translation type="unfinished" variants="no">Salva</translation>
    </message>
    <message>
        <source>Stop</source>
<translation type="unfinished" variants="no">Interrompi</translation>
    </message>
    <message>
        <source>Pause</source>
<translation type="unfinished" variants="no">Pausa</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Record</source>
<translation type="unfinished" variants="no">Registra</translation>
    </message>
    <message>
        <source>New Voice memo</source>
<translation type="unfinished" variants="no">Nuovo promemoria vocale</translation>
    </message>
    <message>
        <source>Saving...</source>
<translation type="unfinished" variants="no">Salvataggio...</translation>
    </message>
    <message>
        <source>no space


stop recording</source>
<translation type="unfinished" variants="no">Interrompere la registrazione per la mancanza di sufficiente spazio nel dispositivo. Eliminare alcuni file, svuotare il cestino e riprovare.</translation>
    </message>
</context>
<context>
    <name>commonDlg::TagListWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Close search results</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>%1 items total</source>
<translation type="unfinished" variants="no">Totale di %1 elementi</translation>
    </message>
</context>
<context>
    <name>ENoteVoiceMemo::NameDialog</name>
    <message>
        <source>Name</source>
<translation type="unfinished" variants="no">Nome</translation>
    </message>
</context>
<context>
    <name>ENoteVoiceMemo::ThumbViewItem</name>
    <message>
        <source>Tag:</source>
<translation type="unfinished" variants="no">Tag:</translation>
    </message>
</context>
<context>
    <name>ImageEditorWidget</name>
    <message>
        <source>Paste</source>
<translation type="unfinished" variants="no">Incolla</translation>
    </message>
    <message>
        <source>Reset</source>
<translation type="unfinished" variants="no">Reset</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ENoteVoiceMemo::VoiceThumbView</name>
    <message>
        <source>Another file with the same name already exists. Please use another name, or delete the file in Recycle Bin</source>
<translation type="unfinished" variants="no">Esiste già un altro file con lo stesso nome. Scegliere un altro nome o eliminare il file nel cestino.</translation>
    </message>
    <message>
        <source>Are you sure you want to delete this voice memo ?</source>
<translation type="unfinished" variants="no">Siete sicuri di voler eliminare il promemoria vocale?</translation>
    </message>
    <message>
        <source>No search results.</source>
<translation type="unfinished" variants="no">La ricerca non ha prodotto alcun risultato.</translation>
    </message>
    <message>
        <source>Illegal name. Cannot contain \:/*?&quot;&lt;>|</source>
<translation type="unfinished" variants="no">Nome non valido. Il nome non può contenere \:/*?&quot;&lt;>|</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>Delete</source>
<translation type="unfinished" variants="no">Elimina</translation>
    </message>
    <message>
        <source>Illegal name. Cannot be blank.</source>
<translation type="unfinished" variants="no">Il campo del nome non può restare vuoto. Inserire un nome.</translation>
    </message>
    <message>
        <source>Cannot find specified file. Please go to [Settings] - [Rescan for Media] and press [Execute] button to rescan for media files.</source>
<translation type="unfinished" variants="no">Impossibile trovare il file specificato. Andare a [Impostazioni] - [Ricerca file multimediali] e selezionare [Cerca] per cercare i file multimediali.</translation>
    </message>
    <message>
        <source>Input the name</source>
<translation type="unfinished" variants="no">Inserire il nome</translation>
    </message>
</context>
<context>
    <name>SearchButtonWidgetNew</name>
    <message>
        <source>Close search result</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>Tag list</source>
<translation type="unfinished" variants="no">Elenco tag</translation>
    </message>
</context>
<context>
    <name>ENoteVoiceMemo::VoicePopMenuItem</name>
    <message>
        <source>Delete</source>
<translation type="unfinished" variants="no">Elimina</translation>
    </message>
    <message>
        <source>Rename</source>
<translation type="unfinished" variants="no">Rinomina</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Invalid password!</source>
<translation type="unfinished" variants="no">La password è errata.</translation>
    </message>
    <message>
        <source>input name is not correct</source>
<translation type="unfinished" variants="no">Il nome è errato.</translation>
    </message>
    <message>
        <source>Not have enough space</source>
<translation type="unfinished" variants="no">Spazio insufficiente.</translation>
    </message>
</context>
<context>
    <name>ENoteVoiceMemo::RecordAddWidget</name>
    <message>
        <source>Record new voice memo</source>
<translation type="unfinished" variants="no">Registra nuovo promemoria vocale</translation>
    </message>
</context>
</TS>
