<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS []>
<TS version="2.0">
<context>
    <name>EnoteMessageBox</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>InputDialog</name>
    <message>
        <source>OK</source>
<translation type="unfinished" variants="no">OK</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>ReNameDialog</name>
    <message>
        <source>Ok</source>
<translation type="unfinished" variants="no">Ok</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>The name already exist. </source>
<translation type="unfinished" variants="no">Il nome esiste già.</translation>
    </message>
    <message>
        <source>please input the name:</source>
<translation type="unfinished" variants="no">Inserire il nome:</translation>
    </message>
</context>
<context>
    <name>ENoteTagWidget::TagWidget</name>
    <message>
        <source>Add</source>
<translation type="unfinished" variants="no">Aggiungi</translation>
    </message>
    <message>
        <source>Close</source>
<translation type="unfinished" variants="no">Chiudi</translation>
    </message>
    <message>
        <source>Tag already exists</source>
<translation type="unfinished" variants="no">Il tag esiste già</translation>
    </message>
    <message>
        <source>Input Tag</source>
<translation type="unfinished" variants="no">Inserisci</translation>
    </message>
    <message>
        <source>Delete the tag:%1?</source>
<translation type="unfinished" variants="no">Eliminare il tag:%1?</translation>
    </message>
    <message>
        <source>Edit Tag</source>
<translation type="unfinished" variants="no">Modifica tag</translation>
    </message>
</context>
<context>
    <name>commonDlg::TagListWidget</name>
    <message>
        <source>Back</source>
<translation type="unfinished" variants="no">Indietro</translation>
    </message>
    <message>
        <source>Close search results</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>A - Z</source>
<translation type="unfinished" variants="no">A - Z</translation>
    </message>
    <message>
        <source>Z - A</source>
<translation type="unfinished" variants="no">Z - A</translation>
    </message>
    <message>
        <source>Snapshot</source>
<translation type="unfinished" variants="no">Istantanea</translation>
    </message>
    <message>
        <source>%1 items total</source>
<translation type="unfinished" variants="no">Totale di %1 elementi</translation>
    </message>
</context>
<context>
    <name>StatusBar</name>
    <message>
        <source>Home</source>
<translation type="unfinished" variants="no">Home</translation>
    </message>
    <message>
        <source>Play</source>
<translation type="unfinished" variants="no">Riproduci</translation>
    </message>
    <message>
        <source>Stop</source>
<translation type="unfinished" variants="no">Interrompi</translation>
    </message>
    <message>
        <source>Time</source>
<translation type="unfinished" variants="no">Ora</translation>
    </message>
    <message>
        <source>Pause</source>
<translation type="unfinished" variants="no">Pausa</translation>
    </message>
    <message>
        <source>Power</source>
<translation type="unfinished" variants="no">Batteria</translation>
    </message>
    <message>
        <source>Wi-Fi</source>
<translation type="unfinished" variants="no">Wi-Fi</translation>
    </message>
    <message>
        <source>Power is too low.Please charge</source>
<translation type="unfinished" variants="no">Batteria scarica.Ricaricare il dispositivo.</translation>
    </message>
    <message>
        <source>Eject safely</source>
<translation type="unfinished" variants="no">Rimuovi</translation>
    </message>
    <message>
        <source>Voice memo playing</source>
<translation type="unfinished" variants="no">Registrazione promemoria vocale...</translation>
    </message>
    <message>
        <source>Music playing</source>
<translation type="unfinished" variants="no">Riproduzione musicale...</translation>
    </message>
    <message>
        <source>Enable</source>
<translation type="unfinished" variants="no">Attiva</translation>
    </message>
    <message>
        <source>Turn off Wi-Fi</source>
<translation type="unfinished" variants="no">Disattiva Wi-Fi</translation>
    </message>
    <message>
        <source>Go to Music Player</source>
<translation type="unfinished" variants="no">Vai a Lettore Musicale</translation>
    </message>
    <message>
        <source>Fail to umount SDcard.
Device or resource busy...</source>
<translation type="unfinished" variants="no">Espulsione scheda SD non riuscita.
Il dispositivo o le applicazioni potrebbero essere occupate.</translation>
    </message>
    <message>
        <source>Record</source>
<translation type="unfinished" variants="no">Registra</translation>
    </message>
    <message>
        <source>Volume</source>
<translation type="unfinished" variants="no">Volume</translation>
    </message>
    <message>
        <source>Go to Voice Memos</source>
<translation type="unfinished" variants="no">Vai a Memo Vocali</translation>
    </message>
    <message>
        <source>Go to Music player</source>
<translation type="unfinished" variants="no">Vai a Lettore Musicale</translation>
    </message>
    <message>
        <source>SD card</source>
<translation type="unfinished" variants="no">Scheda SD</translation>
    </message>
    <message>
        <source>Voice memo recording</source>
<translation type="unfinished" variants="no">Registrazione promemoria vocale...</translation>
    </message>
    <message>
        <source>%1% remains</source>
<translation type="unfinished" variants="no">Rimanente %1%</translation>
    </message>
    <message>
        <source>Rescan now</source>
<translation type="unfinished" variants="no">Cerca</translation>
    </message>
    <message>
        <source>Disable</source>
<translation type="unfinished" variants="no">Disattiva</translation>
    </message>
    <message>
        <source>Turn on Wi-Fi</source>
<translation type="unfinished" variants="no">Attiva Wi-Fi</translation>
    </message>
    <message>
        <source>100% remains</source>
<translation type="unfinished" variants="no">Rimanente 100%</translation>
    </message>
    <message>
        <source>Wifi Setting</source>
<translation type="unfinished" variants="no">Impostazioni Wi-Fi</translation>
    </message>
    <message>
        <source>Soft buttons</source>
<translation type="unfinished" variants="no">Tasti touchpad</translation>
    </message>
    <message>
        <source>Time Setting</source>
<translation type="unfinished" variants="no">Impostazioni Ora</translation>
    </message>
    <message>
        <source>Fail to umount SDcard.
Do you want to close APs and try again?</source>
<translation type="unfinished" variants="no">Espulsione scheda SD non riuscita.
Desiderate chiudere tutte le applicazioni in esecuzione e riprovare?</translation>
    </message>
</context>
<context>
    <name>notifyRule</name>
    <message>
        <source>Loading ...</source>
<translation type="unfinished" variants="no">Caricamento...</translation>
    </message>
    <message>
        <source>saving picture to SD card</source>
<translation type="unfinished" variants="no">Salvataggio immagini su scheda SD...</translation>
    </message>
    <message>
        <source>SD card disconnected. Hit &quot;scan now&quot; to refresh your media library. This will restart your reader, music player, and photo album applications.</source>
<translation type="unfinished" variants="no">Scheda SD inserita. Selezionare [Cerca] per avviare la ricerca dei file multimediali contenuti nella scheda SD.Le applicazioni in esecuzione saranno chiuse e tutti i dati saranno salvati.</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
    <message>
        <source>saving picture to local disk</source>
<translation type="unfinished" variants="no">Salvataggio immagine su disco locale...</translation>
    </message>
    <message>
        <source>Scan now</source>
<translation type="unfinished" variants="no">Cerca</translation>
    </message>
    <message>
        <source>Save picture failed, not enough space in the disk. Please retry after deleting some data</source>
<translation type="unfinished" variants="no">Errore nel salvataggio dell&apos;immagine.Spazio insufficiente nel dispositivo.Eliminare alcuni file e riprovare.</translation>
    </message>
    <message>
        <source>SD card connected. Hit &quot;scan now&quot; to refresh your media library. This will restart your reader, music player, and photo album applications.</source>
<translation type="unfinished" variants="no">Scheda SD inserita. Selezionare [Cerca] per avviare la ricerca dei file multimediali contenuti nella scheda SD. Le applicazioni in esecuzione saranno chiuse e tutti i dati saranno salvati.</translation>
    </message>
    <message>
        <source>shutting down ...</source>
<translation type="unfinished" variants="no">Arresto del sistema ...</translation>
    </message>
    <message>
        <source>reboot system ...</source>
<translation type="unfinished" variants="no">Riavvio del sistema...</translation>
    </message>
    <message>
        <source>saving user data ...</source>
<translation type="unfinished" variants="no">Salvataggio dati</translation>
    </message>
    <message>
        <source>snapshotting ... </source>
<translation type="unfinished" variants="no">Acquisizione immagine completata.</translation>
    </message>
</context>
<context>
    <name>EnoteLogin</name>
    <message>
        <source>Enter</source>
<translation type="unfinished" variants="no">Entra</translation>
    </message>
    <message>
        <source>Auto login when start to use.</source>
<translation type="unfinished" variants="no">Accesso automatico</translation>
    </message>
    <message>
        <source>Please type password</source>
<translation type="unfinished" variants="no">Inserire la password.</translation>
    </message>
    <message>
        <source>Password</source>
<translation type="unfinished" variants="no">Password</translation>
    </message>
    <message>
        <source>Wrong password!</source>
<translation type="unfinished" variants="no">Password errata.</translation>
    </message>
</context>
<context>
    <name>ImageEditorWidget</name>
    <message>
        <source>Paste</source>
<translation type="unfinished" variants="no">Incolla</translation>
    </message>
    <message>
        <source>Reset</source>
<translation type="unfinished" variants="no">Reset</translation>
    </message>
    <message>
        <source>Cancel</source>
<translation type="unfinished" variants="no">Annulla</translation>
    </message>
</context>
<context>
    <name>SearchButtonWidgetNew</name>
    <message>
        <source>Close search result</source>
<translation type="unfinished" variants="no">Fine ricerca</translation>
    </message>
    <message>
        <source>Tag list</source>
<translation type="unfinished" variants="no">Elenco tag</translation>
    </message>
</context>
<context>
    <name>instanceRule</name>
    <message>
        <source>Failed to start the application. The battery is too low.</source>
<translation type="unfinished" variants="no">Errore di avvio dell&apos;applicazione. Batteria scarica.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>Invalid password!</source>
<translation type="unfinished" variants="no">La password è errata.</translation>
    </message>
    <message>
        <source>input name is not correct</source>
<translation type="unfinished" variants="no">Il nome è errato.</translation>
    </message>
    <message>
        <source>Not have enough space</source>
<translation type="unfinished" variants="no">Spazio insufficiente.</translation>
    </message>
</context>
<context>
    <name>CKeyboardFilter</name>
    <message>
        <source>Warning: current process will be killed without saving user data</source>
<translation type="unfinished" variants="no">ATTENZIONE: con la chiusura di questa applicazione, i dati non salvati andranno persi.</translation>
    </message>
</context>
<context>
    <name>keyPressRule</name>
    <message>
        <source>Warning: current process will be killed without saving user data</source>
<translation type="unfinished" variants="no">ATTENZIONE: con la chiusura di questa applicazione, i dati non salvati andranno persi.</translation>
    </message>
</context>
</TS>
